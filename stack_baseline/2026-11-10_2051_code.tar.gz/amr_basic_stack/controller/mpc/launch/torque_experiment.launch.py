#!/usr/bin/env python3
"""토크 MPC 실험 launch (구조도 v3) — 기존 autonomy.launch.py 와 별개다.

기존 스택(RoboClaw, EKF, DRA-MPPI, 인지)은 띄우지 않는다. 기존 경로는 그대로 남겨 둔다.
단계별로 노드가 늘어난다 (amr/notes_amr/stack_changelog.md, torque_mpc_todo.md).

  지금 (2단계):  sim_plant_torque_node (+ RViz)
  3단계:         + torque_mpc_node, torque_output, command_gate(torques), figure8_reference_node
  4단계:         + state_estimator (시뮬 플랜트가 가짜 /tracked_pose·/camera/imu 를 낸다)
  7단계:         plant:=real → ak40_can_node + 센서·Cartographer

사용
  ros2 launch amr_mpc torque_experiment.launch.py                 # 시뮬, RViz 켬
  ros2 launch amr_mpc torque_experiment.launch.py payload_kg:=5.0 # 적재 +5 kg
  ros2 launch amr_mpc torque_experiment.launch.py use_wheel_inertia:=true

손으로 토크 주기 (게이트가 아직 없으므로 /wheel_torque_cmd 에 직접. 시뮬에서만 할 것):
  ros2 topic pub -r 100 /wheel_torque_cmd amr_interfaces/msg/WheelTorqueCommand "{mode: 0, torque: [0.02, 0.02, 0.02, 0.02]}"
  멈추면(Ctrl-C) 0.2 s 뒤 플랜트가 DAMPING 으로 세운다.
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo, OpaqueFunction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def _plant(context):
    plant = LaunchConfiguration("plant").perform(context)
    lc = LaunchConfiguration
    if plant == "sim":
        return [Node(
            package="amr_mpc", executable="sim_plant_torque_node", name="sim_plant_torque_node",
            output="screen",
            parameters=[{
                "payload_kg": ParameterValue(lc("payload_kg"), value_type=float),
                "use_wheel_inertia": ParameterValue(lc("use_wheel_inertia"), value_type=bool),
                "x0": ParameterValue(lc("x0"), value_type=float),
                "y0": ParameterValue(lc("y0"), value_type=float),
                "yaw0": ParameterValue(lc("yaw0"), value_type=float),
            }],
        )]
    if plant == "real":
        return [LogInfo(msg="plant:=real 은 아직 없다 (7단계 ak40_can_node). 아무 플랜트도 띄우지 않는다.")]
    raise RuntimeError(f"plant:={plant!r} — sim 또는 real")


def generate_launch_description():
    share = get_package_share_directory("amr_mpc")
    rviz_cfg = os.path.join(share, "rviz", "torque_experiment.rviz")
    return LaunchDescription([
        DeclareLaunchArgument("plant", default_value="sim", choices=["sim", "real"],
                              description="sim = sim_plant_torque_node, real = ak40_can_node(7단계)"),
        DeclareLaunchArgument("payload_kg", default_value="0.0",
                              description="적재 [kg]. 2차 발표 조건 0 / 5. 몸체 질량은 torque_plant.yaml"),
        DeclareLaunchArgument("use_wheel_inertia", default_value="false",
                              description="모델 바퀴 관성 스위치 (2026-11-10 결정: 기본 끔)"),
        DeclareLaunchArgument("x0", default_value="0.0"),
        DeclareLaunchArgument("y0", default_value="0.0"),
        DeclareLaunchArgument("yaw0", default_value="0.0"),
        DeclareLaunchArgument("use_rviz", default_value="true"),
        OpaqueFunction(function=_plant),
        Node(package="rviz2", executable="rviz2", name="rviz2", output="log",
             arguments=["-d", rviz_cfg], condition=IfCondition(LaunchConfiguration("use_rviz"))),
    ])
