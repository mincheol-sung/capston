"""토크 모델(amr_mpc/torque/model.py) 검산 — 1판 설계의 수치 예와 기구학 부호."""
import math

import numpy as np
import pytest

from amr_mpc.torque.model import NULL_DIR, TorquePlant


@pytest.fixture(params=[False, True], ids=["no_Jw", "with_Jw"])
def plant(request):
    return TorquePlant.from_yaml(use_wheel_inertia=request.param)


def test_null_space_makes_no_motion(plant):
    a = plant.accel(np.zeros(3), np.zeros(3), 0.3 * NULL_DIR)
    assert np.allclose(a, 0.0)


def test_equal_torque_drives_forward(plant):
    tau = 0.1
    a = plant.accel(np.zeros(3), np.zeros(3), [tau] * 4)
    m_eff = plant.M_eff[0, 0]
    assert a[0] == pytest.approx(4 * tau / (plant.r * m_eff))
    assert a[1] == pytest.approx(0.0, abs=1e-12)
    assert a[2] == pytest.approx(0.0, abs=1e-12)


def test_forward_push_rotates_with_heading(plant):
    # θ = 90° 로 북쪽을 보고 있으면 "앞으로" 가 map 의 +y 다
    a = plant.accel(np.array([0.0, 0.0, math.pi / 2]), np.zeros(3), [0.1] * 4)
    assert a[0] == pytest.approx(0.0, abs=1e-12)
    assert a[1] > 0.0


def test_left_and_yaw_patterns_match_driver_kinematics(plant):
    # 드라이버 twist_to_wheels: FL=(vx−vy−kω)/r, FR=(vx+vy+kω)/r, RL=(vx+vy−kω)/r, RR=(vx−vy+kω)/r
    left = plant.accel(np.zeros(3), np.zeros(3), [-0.1, 0.1, 0.1, -0.1])
    assert left[1] > 0 and abs(left[0]) < 1e-12 and abs(left[2]) < 1e-12
    ccw = plant.accel(np.zeros(3), np.zeros(3), [-0.1, 0.1, -0.1, 0.1])
    assert ccw[2] > 0 and abs(ccw[0]) < 1e-12 and abs(ccw[1]) < 1e-12


def test_wheel_speeds_no_slip(plant):
    w = plant.wheel_speeds(np.zeros(3), np.array([0.5, 0.0, 0.0]))
    assert np.allclose(w, 0.5 / plant.r)


def test_wheel_inertia_switch():
    off = TorquePlant.from_yaml(use_wheel_inertia=False)
    on = TorquePlant.from_yaml(use_wheel_inertia=True)
    assert off.mu == 0.0
    assert on.mu == pytest.approx(4 * on.J_w / on.r ** 2)      # J_w 9.7e-4 이면 2.425 kg (1판 식-3)
    assert np.allclose(off.w(np.array([1.0, 0.0, 1.0])), 0.0)
    assert not np.allclose(on.w(np.array([1.0, 0.0, 1.0])), 0.0)


def test_friction_limit_matches_design_example():
    # 1판 식-21 수치 예: μ̂ 0.3, c_s 0.8, m 4 kg → 0.067 N·m
    p = TorquePlant.from_yaml(mass=4.0, mu_hat=0.3, c_s=0.8)
    assert p.tau_friction_limit() == pytest.approx(0.0666, abs=5e-4)


def test_constant_torque_integration_matches_closed_form(plant):
    X, Xd = np.zeros(3), np.zeros(3)
    tau, dt, n = 0.05, 0.001, 1000
    for _ in range(n):
        X, Xd = plant.step(X, Xd, [tau] * 4, dt)
    a = 4 * tau / (plant.r * plant.M_eff[0, 0])
    assert X[0] == pytest.approx(0.5 * a * (n * dt) ** 2, rel=1e-9)
    assert Xd[0] == pytest.approx(a * n * dt, rel=1e-9)
