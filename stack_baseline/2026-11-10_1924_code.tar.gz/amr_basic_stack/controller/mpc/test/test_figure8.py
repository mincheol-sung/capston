# pytest -q controller/mpc/test   (ROS 불필요)
import math

import numpy as np
import pytest

from amr_mpc.core.figure8 import Figure8, wrap

MODES = ("tangent", "fixed")


def make(mode="tangent", **kw):
    d = dict(width=1.4, height=0.8, speed=0.25, accel=0.4, yaw_mode=mode, align_s=1.5)
    return Figure8(**{**d, **kw})


@pytest.mark.parametrize("mode", MODES)
def test_bounding_box_is_exactly_width_by_height(mode):
    """경계상자가 기동 포즈 중심의 W × H 여야 방 크기 검토가 성립한다."""
    f = make(mode)
    xy = np.array(f.path_xy(n=4001))
    assert xy[:, 0].min() == pytest.approx(-f.W / 2, abs=1e-9)
    assert xy[:, 0].max() == pytest.approx(+f.W / 2, abs=1e-9)
    assert xy[:, 1].min() == pytest.approx(-f.H / 2, abs=1e-4)
    assert xy[:, 1].max() == pytest.approx(+f.H / 2, abs=1e-4)


@pytest.mark.parametrize("mode", MODES)
def test_returns_to_start_pose_and_stops(mode):
    """제자리 복귀: 위치·헤딩 둘 다. 8자는 회전지수 0 이라 접선각도 제자리로 온다."""
    f = make(mode)
    assert f.th_tab[-1] - f.th_tab[0] == pytest.approx(0.0, abs=1e-9)
    origin = np.array([1.0, -2.0, 0.7])
    X0, u0 = f.at(0.0, origin)
    Xe, ue = f.at(f.T_total + 1.0, origin)
    assert np.allclose(X0, origin) and np.allclose(u0, 0.0)
    assert np.allclose(Xe, origin, atol=1e-9) and np.allclose(ue, 0.0)


@pytest.mark.parametrize("mode", MODES)
def test_published_twist_matches_derivative_of_published_pose(mode):
    """발행하는 몸체속도가 발행하는 포즈의 도함수인지 유한차분으로 독립 검산.
    둘이 어긋나면 MPC 의 피드포워드(ur)와 오차항(Xr)이 서로 다른 궤적을 가리킨다."""
    f = make(mode)
    origin = np.array([0.3, 0.4, -1.1])
    h = 1e-4
    for t in np.linspace(h, f.T_total - h, 1500):
        Xm, _ = f.at(t - h, origin)
        Xp, _ = f.at(t + h, origin)
        X, u = f.at(t, origin)
        c, s = math.cos(X[2]), math.sin(X[2])
        assert np.allclose([c * u[0] - s * u[1], s * u[0] + c * u[1]],
                           (Xp[:2] - Xm[:2]) / (2 * h), atol=2e-3)
        assert u[2] == pytest.approx(wrap(Xp[2] - Xm[2]) / (2 * h), abs=5e-3)


def test_tangent_mode_drives_forward_only():
    """접선 추종이면 주행 중 몸체 y 속도가 0 — 메카넘 횡슬립을 안 쓴다."""
    f = make("tangent")
    for t in np.linspace(f.T_align, f.T_align + f.T_path, 500):
        u = f.at(t)[1]
        assert abs(u[1]) < 1e-9
        assert u[0] >= -1e-9


def test_speed_profile_is_trapezoidal_and_covers_arc_length():
    f = make("fixed")
    assert f.V == pytest.approx(0.25) and f.t_cru > 0.0
    dt = 1e-3
    dist = sum(f._profile(t)[1] for t in np.arange(0.0, f.T_path, dt)) * dt
    assert dist == pytest.approx(f.L, rel=1e-3)          # ∫v dt = 호길이


def test_triangular_profile_when_path_too_short_to_cruise():
    f = Figure8(width=0.2, height=0.1, speed=2.0, accel=0.4, yaw_mode="fixed")
    assert f.V < 2.0 and f.t_cru == pytest.approx(0.0, abs=1e-9)
    assert f.V == pytest.approx(math.sqrt(0.4 * f.L))


def test_rejects_bad_parameters():
    for kw in ({"width": 0.0}, {"height": -1.0}, {"speed": 0.0}, {"accel": -0.1},
               {"laps": 0.0}, {"yaw_mode": "spin"}):
        with pytest.raises(ValueError):
            make(**kw)
