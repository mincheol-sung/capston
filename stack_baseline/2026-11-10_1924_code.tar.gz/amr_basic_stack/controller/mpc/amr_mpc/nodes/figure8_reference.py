#!/usr/bin/env python3
# 8자 기준궤적 발행 노드 — mpc_tracking_node 가 그대로 받아 추종한다.
# fake_reference_node(원궤적)의 8자판.  궤적 수식·검산은 figure8.py.
# ---------------------------------------------------------------
#   /odometry/filtered              (nav_msgs/Odometry)      첫 포즈를 8자의 교차점(원점)으로 잡는다
#      ↓
#   /dra_mppi/reference_trajectory  (PlanarReferenceArray, 10 Hz, dt 0.2 s × 20)  ← mpc_tracking_node 의 입력
#   /figure8/path                   (nav_msgs/Path, latched)  RViz 로 경로 전체 확인
#
# 진행
#   [정렬 회전 align_s] → [8자 laps 바퀴] → [역정렬 회전 align_s] → [기동 포즈 유지 hold_s] → 발행 중단
#   발행이 끊기면 mpc_tracking_node 가 ref_timeout(0.5 s) 뒤 /cmd_vel 0 을 내고 멈춘다.
#   yaw_mode=fixed 면 정렬 회전이 없다 (헤딩 고정 게걸음).
#
# 부하 예산
#   기준 부하 |vx|+|vy|+K_GEOM·|ω| 가 load_budget·V_LIMIT 를 넘으면 뜨지 않고 거부한다
#   (fake_reference_node 와 같은 규칙).  남는 35 % 가 MPC 의 보정 여유다.
#
# 예)  ros2 run amr_mpc figure8_reference_node --ros-args -p width:=1.4 -p height:=1.0 -p speed:=0.25
# ---------------------------------------------------------------
import math
import numpy as np
import signal
import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from rclpy.signals import SignalHandlerOptions
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry, Path
from amr_interfaces.msg import PlanarReference, PlanarReferenceArray

from amr_mpc.body import mpc as mpc_mod
from amr_mpc.core.figure8 import Figure8
K_GEOM = mpc_mod.K_GEOM


def yaw_of(q):
    return math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))


class Figure8ReferenceNode(Node):
    def __init__(self):
        super().__init__("figure8_reference_node")
        self.declare_parameters("", [
            # 8자 모양 — 경계상자가 정확히 width × height 이고 기동 포즈가 그 중심이다.
            # 방 2.0 m, 로봇 외접반경 0.18 m 이면 1.4 폭에서 좌우 여유 0.12 m.
            # height 는 곡률을 정한다 (잎사귀 꼭대기 κ ≈ 16H/W²) — 헤딩 오차와 부하가 여기서 나온다.
            # 폐루프 시뮬(초기오차 10 cm, v 0.25): H 1.0/0.8/0.6/0.4 → 헤딩오차 최대
            # 12.5/9.8/7.7/6.0 °, 부하 67/59/53/49 %.  위치오차는 1.3 cm 로 거의 안 변한다.
            # 기본 0.8 은 잎사귀가 0.7 × 0.8 로 가장 둥근 지점.
            ("width", 1.4), ("height", 0.8),
            ("speed", 0.25),                          # 순항 접선속도 [m/s]
            ("accel", 0.4),                           # 호길이 축 가감속 [m/s²]
            ("laps", 1.0),                            # 바퀴 수. 1 바퀴마다 기동 포즈로 돌아온다
            ("yaw_mode", "tangent"),                  # tangent = 접선 추종 | fixed = 헤딩 고정(게걸음)
            ("align_s", 1.5),                         # tangent 모드 앞뒤 제자리 회전 시간 [s]
            ("start_delay", 3.0),                     # 첫 odom 뒤 이만큼 기동 포즈를 유지하다 출발 (실차에서 손 뺄 시간)
            ("abort_error", 0.35),                    # 로봇이 기준에서 이만큼 벌어지면 발행 중단 → MPC 타임아웃 정지.
                                                      # 2026-09-03 실차에서 오차 2.8 m 까지 달아났다. 0 이하면 끈다.
            ("hold_s", 5.0),                          # 복귀 후 제자리 유지 시간. <0 이면 무한 유지
            ("rate_hz", 10.0), ("dt", 0.2), ("horizon_steps", 20),
            ("frame_id", "odom"),
            ("odom_topic", "/odometry/filtered"),
            ("reference_topic", "/dra_mppi/reference_trajectory"),
            ("max_wheel_rad_per_sec", mpc_mod.W_MAX),  # base.yaml·mpc.yaml 과 같게. V_LIMIT = 0.04 × 이 값
            ("load_budget", mpc_mod.LOAD_BUDGET),
        ])
        g = lambda n: self.get_parameter(n).value
        self.dt, self.T, self.frame = float(g("dt")), int(g("horizon_steps")), str(g("frame_id"))
        self.hold, self.delay = float(g("hold_s")), max(0.0, float(g("start_delay")))
        self.abort = float(g("abort_error"))

        mpc_mod.set_wheel_limit(g("max_wheel_rad_per_sec"))
        V_LIMIT, budget = mpc_mod.V_LIMIT, float(g("load_budget"))
        try:
            self.path = Figure8(width=g("width"), height=g("height"), speed=g("speed"),
                                accel=g("accel"), laps=g("laps"), yaw_mode=str(g("yaw_mode")),
                                align_s=g("align_s"))
        except ValueError as e:
            raise SystemExit(f"[figure8] 파라미터 오류: {e}")

        run, spin = self.path.peak_load(K_GEOM)
        cap = budget * V_LIMIT
        if run > cap:                                 # 주행 부하는 speed 에 선형
            raise SystemExit(
                f"[figure8] 기준 부하 {run:.3f} > 예산 {cap:.3f} ({budget*100:.0f} % of {V_LIMIT:.2f}). "
                f"speed 를 {float(g('speed')) * cap / run:.3f} m/s 이하로 낮추거나 height 를 줄여라 "
                f"(최대곡률 {self.path.max_curvature():.2f} 1/m 이 ω=κv 를 키운다).")
        if spin > cap:                                # 정렬 회전 부하는 align_s 에 반비례
            raise SystemExit(f"[figure8] 정렬 회전 부하 {spin:.3f} > 예산 {cap:.3f}. "
                             f"align_s 를 {float(g('align_s')) * spin / cap:.2f} s 이상으로 늘려라.")

        self.origin = None; self.t0 = None; self.finished = False; self.pose = None
        self.pub = self.create_publisher(PlanarReferenceArray, str(g("reference_topic")), 5)
        self.pub_path = self.create_publisher(
            Path, "/figure8/path", QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL))
        self.create_subscription(Odometry, str(g("odom_topic")), self.cb_odom, 10)
        self.create_timer(1.0 / float(g("rate_hz")), self.on_tick)

        p = self.path
        self.get_logger().info(
            f"8자 {p.W:.2f} × {p.H:.2f} m (Gerono 렘니스케이트)  yaw {p.yaw_mode}  {p.laps:g} 바퀴\n"
            f"  호길이 {p.L:.2f} m  순항 {p.V:.2f} m/s  가감속 {p.A:.2f} m/s²  "
            f"최대곡률 {p.max_curvature():.2f} 1/m (R_min {1/p.max_curvature():.3f} m)\n"
            f"  시간  대기 {self.delay:.1f} s + 정렬 {p.T_align:.1f} s ×2 + 주행 {p.T_path:.1f} s = {p.T_total:.1f} s"
            f"{'' if self.hold < 0 else f' + 유지 {self.hold:.1f} s'}\n"
            f"  부하  주행 {run/V_LIMIT*100:.0f} %  정렬 {spin/V_LIMIT*100:.0f} %  "
            f"(예산 {budget*100:.0f} %, V_LIMIT {V_LIMIT:.2f} m/s)  → 보정 여유 {(1-run/V_LIMIT)*100:.0f} %")

    # ---------- 콜백 ----------
    def cb_odom(self, m):
        p = m.pose.pose
        self.pose = np.array([p.position.x, p.position.y])
        if self.origin is not None:
            return
        self.origin = np.array([p.position.x, p.position.y, yaw_of(p.orientation)])
        self.t0 = self.get_clock().now().nanoseconds * 1e-9
        self.get_logger().info(f"기동 포즈(8자 교차점) x {self.origin[0]:.3f}  y {self.origin[1]:.3f}  "
                               f"yaw {math.degrees(self.origin[2]):.1f}°  — {self.delay:.1f} s 뒤 출발")
        self.publish_path()

    def publish_path(self):
        msg = Path(); msg.header.frame_id = self.frame
        msg.header.stamp = self.get_clock().now().to_msg()
        for x, y in self.path.path_xy(origin=self.origin):
            ps = PoseStamped(); ps.header = msg.header
            ps.pose.position.x, ps.pose.position.y = float(x), float(y)
            ps.pose.orientation.w = 1.0
            msg.poses.append(ps)
        self.pub_path.publish(msg)

    def on_tick(self):
        if self.origin is None or self.finished:
            return
        now = self.get_clock().now()
        t = now.nanoseconds * 1e-9 - self.t0 - self.delay      # t<0 이면 at() 이 기동 포즈·속도 0 을 낸다
        if 0.0 <= self.hold and t > self.path.T_total + self.hold:
            self.finished = True
            self.get_logger().info(f"8자 완주 + 유지 {self.hold:.1f} s 끝 — 발행 중단. "
                                   f"MPC 가 곧 타임아웃으로 정지한다.")
            return
        if self.abort > 0.0 and self.pose is not None:      # 발산 비상정지 — MPC 가 못 잡으면 여기서 끊는다
            err = float(np.hypot(*(self.pose - self.path.at(t, self.origin)[0][:2])))
            if err > self.abort:
                self.finished = True
                self.get_logger().error(
                    f"중단: 기준에서 {err*100:.1f} cm 벗어남 (한계 {self.abort*100:.1f} cm). 발행을 끊는다 — MPC 가 곧 정지한다.\n"
                    f"  체크: odom_topic 이 /odom 인가 (EKF 를 끼면 모델에 없는 지연이 붙는다),"
                    f" mpc/status 의 부하·QP 반복, speed 를 낮췄는가")
                return

        msg = PlanarReferenceArray()
        msg.header.stamp = now.to_msg(); msg.header.frame_id = self.frame; msg.dt = self.dt
        for i in range(self.T):                        # references[i] 의 목표 시각 = stamp + (i+1)·dt
            Xr, ur = self.path.at(t + (i + 1) * self.dt, self.origin)
            r = PlanarReference(); r.header = msg.header
            r.x, r.y, r.yaw = map(float, Xr); r.vx, r.vy, r.yaw_rate = map(float, ur)
            msg.references.append(r)
        self.pub.publish(msg)


def main():
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = Figure8ReferenceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        signal.signal(signal.SIGINT, signal.SIG_IGN)   # 정리 중 두 번째 Ctrl+C(launch 가 보냄) 무시
        try: node.destroy_node()
        except Exception: pass
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
