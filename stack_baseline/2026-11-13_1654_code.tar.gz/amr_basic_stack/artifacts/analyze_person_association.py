#!/usr/bin/env python3
"""Extract person camera/LiDAR association failures from ROS 2 MCAP bags."""

import argparse
import json
import math
from pathlib import Path

import numpy as np
import rosbag2_py
from rclpy.serialization import deserialize_message

from amr_interfaces.msg import DetectedObjectArray


TOPICS = ['/detections', '/lidar_clusters', '/detections_fused']


def stamp_seconds(stamp):
    return float(stamp.sec) + float(stamp.nanosec) * 1e-9


def read_bag(path):
    reader = rosbag2_py.SequentialReader()
    reader.open(
        rosbag2_py.StorageOptions(uri=str(path), storage_id='mcap'),
        rosbag2_py.ConverterOptions('', ''),
    )
    reader.set_filter(rosbag2_py.StorageFilter(topics=TOPICS))
    messages = {topic: [] for topic in TOPICS}
    while reader.has_next():
        topic, raw, record_ns = reader.read_next()
        msg = deserialize_message(raw, DetectedObjectArray)
        header_time = stamp_seconds(msg.header.stamp)
        objects = []
        for obj in msg.objects:
            objects.append({
                'class_name': str(obj.class_name).strip().lower(),
                'class_id': int(obj.class_id),
                'source': int(obj.source),
                'confidence': float(obj.confidence),
                'x': float(obj.position.x),
                'y': float(obj.position.y),
                'z': float(obj.position.z),
                'distance': float(obj.distance),
                'width': float(obj.bbox.size_x),
            })
        messages[topic].append({
            't': header_time if header_time > 0.0 else record_ns * 1e-9,
            'record_t': record_ns * 1e-9,
            'objects': objects,
        })
    return messages


def nearest_message(messages, t, max_dt=0.067):
    if not messages:
        return None
    times = np.fromiter((m['t'] for m in messages), dtype=float)
    index = int(np.argmin(np.abs(times - t)))
    if abs(messages[index]['t'] - t) > max_dt:
        return None
    return messages[index]


def nearest_object(objects, x, y):
    if not objects:
        return None
    return min(objects, key=lambda o: math.hypot(o['x'] - x, o['y'] - y))


def summarize(path):
    messages = read_bag(path)
    fused_frames = messages['/detections_fused']
    persons = []
    for frame in fused_frames:
        for obj in frame['objects']:
            if obj['class_name'] != 'person':
                continue
            lidar_frame = nearest_message(messages['/lidar_clusters'], frame['t'])
            nearest = None
            if lidar_frame is not None:
                nearest = nearest_object(lidar_frame['objects'], obj['x'], obj['y'])
            row = {
                't': frame['t'],
                'source': obj['source'],
                'camera': obj,
                'lidar_t': None if lidar_frame is None else lidar_frame['t'],
                'lidar': nearest,
            }
            if nearest is not None:
                row['separation'] = math.hypot(
                    nearest['x'] - obj['x'], nearest['y'] - obj['y'])
            persons.append(row)
    counts = {str(source): sum(p['source'] == source for p in persons)
              for source in (0, 1, 2)}
    return {
        'bag': str(path),
        'topic_counts': {topic: len(frames) for topic, frames in messages.items()},
        'person_count': len(persons),
        'source_counts': counts,
        'persons': persons,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('bags', nargs='+')
    parser.add_argument('--output')
    parser.add_argument('--summary-only', action='store_true')
    args = parser.parse_args()
    reports = [summarize(Path(path)) for path in args.bags]
    if args.summary_only:
        reports = [{key: value for key, value in report.items() if key != 'persons'}
                   for report in reports]
    text = json.dumps(reports, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(text, encoding='utf-8')
    else:
        print(text)


if __name__ == '__main__':
    main()
