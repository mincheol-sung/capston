-- ============================================================================
-- localization_2d.lua — 저장된 맵(.pbstream) 위에서 순수 측위만 수행.
--
-- mapping_2d.lua 를 베이스로 하고 달라지는 것만 덮어쓴다. 여기 없는 항목은
-- 매핑과 완전히 동일하다(센서 토픽, IMU 사용, 상관 스캔매칭, TF 소유권 등).
--
-- 실행 시 반드시 -load_state_filename 으로 .pbstream 을 넘겨야 한다.
-- 초기 위치는 set_initial_pose_node 가 RViz "2D Pose Estimate" 로 받아
-- FinishTrajectory + StartTrajectory(use_initial_pose) 로 재시작시킨다.
--
-- ※ 이 모드에서 cartographer 가 내는 점유격자(/map_carto)는 새로 만든 서브맵
--   3개뿐이다(pure_localization_trimmer). 전체 맵이 아니다. 전체 맵은 매핑 때
--   저장한 .png/.yaml 이며, planner 는 그 파일을 직접 읽는다.
-- ============================================================================

include "mapping_2d.lua"

-- ── cartographer_ros 옵션 ──
options.pose_publish_period_sec = 1e-2         -- 매핑: 5e-3
options.trajectory_publish_period_sec = 30e-3

-- 측위는 실시간 응답이 중요하고 서브맵 생성이 적어 여유가 있다.
MAP_BUILDER.num_background_threads = 6         -- 매핑: 4

-- ── 프론트엔드 ──
-- ceres_scan_matcher.rotation_weight 는 스캔 정합 결과가 추측항법(IMU+휠)
-- 예측의 '회전'에서 벗어나는 것을 얼마나 벌하는지다. 낮출수록 라이다 쪽으로
-- 자유롭게 돌고, 높일수록 자이로 예측에 묶인다.
--
-- 여기는 매핑과 같은 40(= cartographer 기본값,
-- cartographer/configuration_files/trajectory_builder_2d.lua:48)을 쓴다.
-- 이유:
--   * 지금 얼어붙은 맵 자체가 40 으로 만들어졌다(mapping_2d.lua). 맵을 만든
--     조건과 맞추는 편이 정합이 안정적이다.
--   * 공식 순수측위 레퍼런스(backpack_2d_localization.lua)도 이 값을 건드리지
--     않는다. 그 파일이 매핑 설정에서 바꾸는 것은 pure_localization_trimmer 와
--     optimize_every_n_nodes 둘뿐이다.
--   * 낮추면 휠 yaw 뿐 아니라 D455 자이로가 잡아주던 회전 앵커까지 같이
--     풀린다. 메카넘 휠 yaw 는 못 믿지만 자이로는 믿을 만하다.
--
-- (이전에는 1.0 이었고 "레퍼런스 값 0.1" 이라는 주석이 붙어 있었다. 그 0.1 은
--  real_time_correlative_scan_matcher.rotation_delta_cost_weight 로 완전히
--  다른 파라미터다.)
--
-- 회전 추종이 눈에 띄게 굼뜨면 낮춰볼 수 있다. 단 한 번에 하나씩,
-- 20 -> 10 정도로 단계적으로.
TRAJECTORY_BUILDER_2D.ceres_scan_matcher.rotation_weight = 40.

-- ── 백엔드: 순수 측위 ──
-- 새로 만드는 서브맵을 3개만 유지한다. 이게 없으면 측위 중에도 맵이 계속
-- 자라서 메모리와 CPU 가 무한히 는다.
TRAJECTORY_BUILDER.pure_localization_trimmer = {
  max_submaps_to_keep = 3,
}

-- 측위는 매핑(100)보다 자주 최적화해야 pose 가 빨리 따라온다. 다만 최적화가
-- 돌 때마다 궤적 전체가 조금씩 재배치되므로, 너무 잦으면 그 재배치가 그대로
-- pose 떨림으로 보인다. 공식 순수측위 레퍼런스와 같은 20 을 쓴다.
-- (이전 값 3 은 레퍼런스보다 7배 잦았다.)
POSE_GRAPH.optimize_every_n_nodes = 20

POSE_GRAPH.constraint_builder.sampling_ratio = 0.3
POSE_GRAPH.constraint_builder.fast_correlative_scan_matcher.linear_search_window = 2.
POSE_GRAPH.constraint_builder.fast_correlative_scan_matcher.angular_search_window = math.rad(30.)

-- ★ 얼어붙은 맵과의 궤적 간 매칭 정책
--
-- 순수 측위에서 새 궤적(1번)이 얼어붙은 궤적(0번)에 처음 붙는 유일한 통로가
-- GLOBAL 탐색이다. cartographer 는 노드-서브맵 쌍마다
--
--     같은 궤적이거나, 두 궤적이 최근에 이어진 적이 있으면  -> LOCAL 탐색
--     그렇지 않으면                                          -> GLOBAL 탐색
--                                                    (샘플러가 뽑았을 때만)
--
-- 로 판정한다. 갓 시작한 궤적 1 은 궤적 0 과 아직 한 번도 이어진 적이 없으므로
-- LOCAL 분기에 들어갈 수 없다. 따라서 global_sampling_ratio = 0 이면 샘플러가
-- 영원히 안 뽑히고, 정합을 시도조차 안 한 채 새로 만든 서브맵 3개 위에서만
-- 추측항법으로 흘러간다. RViz "2D Pose Estimate" 로 초기 위치를 정확히 찍어도
-- 마찬가지다. 초기 pose 는 좌표계 정렬만 해줄 뿐 궤적을 이어주지는 않는다.
--
-- 그래서 기본값 0.003 을 쓴다. 처음 한 번 붙고 나면
-- global_constraint_search_after_n_seconds(아래) 동안은 LOCAL 탐색만 쓰므로,
-- 비싼 전체 탐색은 부팅 직후에만 돈다.
--
-- 순간이동(엉뚱한 통로에 붙음)은 이 값을 0 으로 막는 게 아니라
-- constraint_builder.global_localization_min_score 로 막는다. mapping_2d.lua
-- 에서 0.75 로 올려뒀다(기본값 0.6). 그래도 튀면 그 값을 더 올릴 것.
--
-- 초기 락이 느리면 이 값을 키운다(0.01~0.05). 대신 부팅 직후 CPU 를 더 쓴다.
POSE_GRAPH.global_sampling_ratio = 0.003

-- 마지막 궤적 간 구속 이후 LOCAL 탐색을 계속 쓰는 유예 시간. 크게 잡으면 한 번
-- 붙은 뒤에는 GLOBAL 탐색이 사실상 안 돌아서, 주행 중 순간이동 위험이 없다.
POSE_GRAPH.global_constraint_search_after_n_seconds = 1000.

return options
