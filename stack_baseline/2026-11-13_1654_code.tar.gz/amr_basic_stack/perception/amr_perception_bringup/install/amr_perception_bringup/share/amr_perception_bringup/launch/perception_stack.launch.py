#!/usr/bin/env python3
"""전체 인지 스택 STUB 통합 launch — 모듈 연결성 검증용.

파이프라인:
  (센서) -> sensor_fusion -> /detections -> object_tracker -> /tracks
    -> dynamic_filter -> /scan_static -> semantic_slam -> /map
    -> motion_predictor -> /predictions -> risk_model -> /risk

실행:
  ros2 launch amr_perception_bringup perception_stack.launch.py
연결성 확인:
  rqt_graph  (또는 ros2 topic list / ros2 node list)
"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    # yolo_model_path: OpenVINO 모델 폴더. 비면 sensor_fusion이 stub(빈 검출)로 동작.
    yolo_model = LaunchConfiguration('yolo_model_path')
    use_semantic_slam = LaunchConfiguration('use_semantic_slam')
    # 노드가 double 로 선언하므로 문자열 그대로 넘기면 타입 불일치로 죽는다.
    yolo_conf = ParameterValue(LaunchConfiguration('yolo_conf'), value_type=float)
    # C단계 실험 정의 파라미터. 기본값 = 노드 기본값이라 기존 실행은 그대로 동작한다.
    # launch 로 노출하는 이유: 실험 설정을 시작 시점에 못 박아야 재현이 된다.
    cam_pos_method = LaunchConfiguration('camera_position_method')
    depth_roi_ratio = ParameterValue(
        LaunchConfiguration('depth_roi_ratio'), value_type=float)
    min_valid_px = ParameterValue(
        LaunchConfiguration('min_valid_depth_pixels'), value_type=int)
    lid_pos_method = LaunchConfiguration('cluster_position_method')

    other_modules = [
        ('object_tracker', 'object_tracker_node'),
        ('dynamic_filter', 'dynamic_filter_node'),
        ('motion_predictor', 'motion_predictor_node'),
        ('risk_model', 'risk_model_node'),
    ]
    return LaunchDescription([
        DeclareLaunchArgument('yolo_model_path', default_value='',
                              description='YOLO OpenVINO 모델 폴더 경로. 비면 stub.'),
        DeclareLaunchArgument('use_semantic_slam', default_value='true',
                              description='Start semantic_slam stub publisher.'),
        # 거리별 신뢰도 측정 시 낮춰서(예 0.05) 절단 없는 confidence 분포를 받는다.
        DeclareLaunchArgument('yolo_conf', default_value='0.4',
                              description='YOLO score threshold.'),
        # 카메라 객체 대표점(object representative position) 산출 방식.
        # roi_median_3d = bbox 중앙 ROI 유효 depth 전체의 좌표별 median (C2 실험 정의)
        # center_patch  = bbox 중심 창의 depth median 1점 (C1 실험 방식, 비교용)
        DeclareLaunchArgument('camera_position_method', default_value='roi_median_3d',
                              description='roi_median_3d | center_patch'),
        DeclareLaunchArgument('depth_roi_ratio', default_value='0.5',
                              description='bbox 중앙 ROI 비율 (0, 1].'),
        DeclareLaunchArgument('min_valid_depth_pixels', default_value='20',
                              description='ROI 내 유효 depth 픽셀 하한.'),
        DeclareLaunchArgument('cluster_position_method', default_value='mean_centroid',
                              description='mean_centroid | median | nearest_point'),
        Node(package='sensor_fusion', executable='rgbd_detection_node',
             name='rgbd_detection_node', output='screen',
             parameters=[{'yolo_model_path': yolo_model, 'yolo_conf': yolo_conf,
                          'camera_position_method': cam_pos_method,
                          'depth_roi_ratio': depth_roi_ratio,
                          'min_valid_depth_pixels': min_valid_px}]),
        Node(package='sensor_fusion', executable='detection_markers',
             name='detection_markers', output='screen'),
        # 라이다 단독 객체 검출(ABD 클러스터링) -> /lidar_clusters
        # 융합의 LiDAR 측 입력. 없으면 Camera X + LiDAR O 케이스가 불가능.
        Node(package='sensor_fusion', executable='lidar_cluster_node',
             name='lidar_cluster_node', output='screen',
             parameters=[{'cluster_position_method': lid_pos_method}]),
        Node(package='semantic_slam', executable='semantic_slam_node',
             name='semantic_slam_node', output='screen',
             condition=IfCondition(use_semantic_slam)),
    ] + [
        Node(package=pkg, executable=exe, name=exe, output='screen')
        for pkg, exe in other_modules
    ])
