#!/usr/bin/env python3
"""토크 MPC 실험 launch (구조도 v3) — 기존 autonomy.launch.py 와 별개다.

기존 스택(RoboClaw, EKF, DRA-MPPI, 인지)은 띄우지 않는다. 기존 경로는 그대로 남겨 둔다.
단계별로 노드가 늘어난다 (amr/notes_amr/stack_changelog.md, torque_mpc_todo.md).

  지금 (4단계) — 시뮬 폐루프:
    figure8_reference_node ─기준열─▶ torque_mpc_node ─▶ torque_output_node ─▶ 게이트('a' 무장) ─▶ sim_plant_torque_node
                                          ▲                                                          │ 가짜 IMU 200 Hz,
                                          └── /state_estimator/odom ◀── state_estimator_node ◀───────┘ 가짜 SLAM 포즈 10 Hz (0.13 s 늦게)
  7단계:  plant:=real → ak40_can_node + 센서·Cartographer

  state_source:=truth       추정기 없이 시뮬 참값(/sim/ground_truth)을 바로 쓴다 (3단계 방식, 제어기만 볼 때)
  slam_mode:=extrapolated   지금 실차 Cartographer 설정 흉내 (외삽 켬, 100 Hz). 기본 scan_time = 외삽 끔
  sensor_noise_scale:=0     센서 잡음 없이 (바이어스·지연은 그대로)
  wheel_odom:=true          휠 오돔(/wheel_odom)을 만든다 — Cartographer 초기 짐작용 선택 입력. 기본은
                            config/torque_estimator.yaml slam.use_wheel_odom (false). 시뮬에는 Cartographer 가 없어
                            노드만 뜬다. 실차(7단계)에서는 Cartographer lua 도 휠 오돔 켠 판으로 고른다

사용 (새 터미널에서 amr 을 먼저)
  ros2 launch amr_mpc torque_experiment.launch.py                       # 8자 한 바퀴. 이 터미널에서 a = 무장, s/SPACE = 정지
                                                                        #   무장해야 기준 시간이 흐른다. 정지하면 기준도 멈추고, 다시 a 로 이어 간다
  ros2 launch amr_mpc torque_experiment.launch.py armed:=true           # 띄우자마자 무장 (시뮬에서만)
  ros2 launch amr_mpc torque_experiment.launch.py limit_mode:=friction  # 비교군 C (마찰 토크 상한). 기본 motor_only = B
  ros2 launch amr_mpc torque_experiment.launch.py disturbance:=true     # 외란 추정치 d̂ 켬 (기본 끔)
  ros2 launch amr_mpc torque_experiment.launch.py payload_kg:=5.0       # 적재 +5 kg (플랜트와 제어기 둘 다)
  ros2 launch amr_mpc torque_experiment.launch.py payload_kg:=5.0 ctrl_payload_kg:=0.0   # 제어기는 모름 (질량 오차 시험)
  ros2 launch amr_mpc torque_experiment.launch.py use_mpc:=false        # 플랜트·RViz 만 (손으로 토크 주기, tools/torque_demo_drive.py)
  8자 위치·모양·속도는 config/torque_track.yaml (지도 고정, 2026-11-11). 한 번만 바꿀 때: speed:=0.8 laps:=2 origin_x:=1.0
    로봇을 출발점(origin) 근처에 놓고 'a' — 30 cm·30° 안이면 천천히 출발점으로 들어간 뒤 8자, 밖이면 출발 거부.
    예전처럼 로봇이 있는 곳을 교차점으로: origin_mode:=robot

비워 두는 인자는 config/*.yaml 값을 쓴다 (torque_plant, torque_mpc, torque_track).
"""
import yaml
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo, OpaqueFunction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _truthy(s):
    return str(s).strip().lower() in ("true", "1", "yes", "on")


# config/torque_track.yaml 의 키. launch 인자 이름이 같고, 비워 두면 YAML 값을 쓴다
_TRACK_KEYS = ["origin_mode", "origin_x", "origin_y", "origin_yaw_deg", "start_tolerance_xy",
               "start_tolerance_yaw_deg", "lead_speed", "lead_yaw_rate", "width", "height", "yaw_mode",
               "speed", "accel", "laps", "align_s", "start_delay", "abort_error", "hold_s", "lap_speeds"]


def _track(context, share):
    with open(os.path.join(share, "config", "torque_track.yaml")) as f:
        track = yaml.safe_load(f)["track"]
    for k in _TRACK_KEYS:
        v = LaunchConfiguration(k).perform(context).strip()
        if v:
            track[k] = v
    out = {}
    for k in _TRACK_KEYS:                             # 노드 파라미터 타입에 맞춘다
        if k == "lap_speeds":                         # 목록. launch 인자는 "[0.3, 0.5]" 꼴 문자열
            v = yaml.safe_load(track[k]) if isinstance(track[k], str) else track[k]
            out[k] = [float(x) for x in (v or [])] or [0.0]
        else:
            out[k] = str(track[k]) if k in ("origin_mode", "yaw_mode") else float(track[k])
    return out


def _nodes(context):
    g = lambda n: LaunchConfiguration(n).perform(context).strip()
    share = get_package_share_directory("amr_mpc")
    plant = g("plant")
    source, slam_mode = g("state_source"), g("slam_mode")
    state_topic = g("state_topic") or ("/state_estimator/odom" if source == "estimator" else "/sim/ground_truth")
    nodes = []

    # 측위 입력 선택 (휠 오돔 스위치) — config/torque_estimator.yaml slam 절, launch 인자 wheel_odom 이 덮어쓴다
    with open(os.path.join(share, "config", "torque_estimator.yaml")) as f:
        slam = yaml.safe_load(f)["slam"]
    use_wheel_odom = _truthy(g("wheel_odom")) if g("wheel_odom") else bool(slam["use_wheel_odom"])
    carto_lua = slam["lua_with_wheel_odom"] if use_wheel_odom else slam["lua_without_wheel_odom"]
    if use_wheel_odom:
        nodes.append(Node(
            package="amr_mpc", executable="wheel_odometry_node", name="wheel_odometry_node", output="screen",
            parameters=[{"output_topic": slam["wheel_odom_topic"]}]))

    # 플랜트와 제어기가 같이 쓰는 모델 설정. 비어 있으면 YAML 값
    shared = {}
    if g("use_wheel_inertia"):
        shared["use_wheel_inertia"] = _truthy(g("use_wheel_inertia"))
    payload = float(g("payload_kg"))

    # ── 플랜트
    if plant == "sim":
        nodes.append(Node(
            package="amr_mpc", executable="sim_plant_torque_node", name="sim_plant_torque_node", output="screen",
            parameters=[{**shared, "payload_kg": payload,
                         "x0": float(g("x0")), "y0": float(g("y0")), "yaw0": float(g("yaw0")),
                         "sensors": source == "estimator", "slam_mode": slam_mode,
                         "sensor_noise_scale": float(g("sensor_noise_scale")),
                         "surface_mu": float(g("surface_mu")) if g("surface_mu") else -1.0}]))
    elif plant == "real":
        nodes.append(LogInfo(msg=f"plant:=real 은 아직 없다 (7단계 ak40_can_node). 아무 플랜트도 띄우지 않는다. "
                                 f"그때 Cartographer 는 {carto_lua} 로 띄운다 (휠 오돔 {'켬' if use_wheel_odom else '끔'})."))
    else:
        raise RuntimeError(f"plant:={plant!r} — sim 또는 real")

    # ── 상태 추정기 (SLAM 포즈 + IMU → 100 Hz 상태)
    if source == "estimator":
        nodes.append(Node(
            package="amr_mpc", executable="state_estimator_node", name="state_estimator_node", output="screen",
            parameters=[{"pose_source": "stamped" if slam_mode == "scan_time" else "after_scan_match"}]))

    if not _truthy(g("use_mpc")):
        return nodes

    # ── 기준궤적: 8자 시간 기준 (기동 포즈가 교차점)
    if _truthy(g("use_figure8")):
        nodes.append(Node(
            package="amr_mpc", executable="figure8_reference_node", name="figure8_reference_node", output="screen",
            parameters=[{
                **_track(context, share),
                "frame_id": "map", "odom_topic": state_topic,
                "wait_for_arm": True, "armed_topic": "/mpc/armed",   # 무장된 동안만 기준 시간이 흐른다
                # 기준 부하 검사용 바퀴 최고속도. AK40-10 무부하 추정 402 rpm = 42 rad/s (22.2 V, 미실측 — To do 1절)
                "max_wheel_rad_per_sec": float(g("max_wheel_rad_per_sec")),
            }]))

    # ── 제어기. payload_kg 는 "제어기가 믿는" 적재 (비우면 플랜트와 같게)
    ctrl = {**shared, "state_topic": state_topic, "armed_topic": "/mpc/armed",
            "payload_kg": float(g("ctrl_payload_kg")) if g("ctrl_payload_kg") else payload,
            "log_prefix": g("log_prefix")}
    if g("limit_mode"):
        ctrl["limit_mode"] = g("limit_mode")
    if g("disturbance"):
        ctrl["disturbance_enable"] = _truthy(g("disturbance"))
    if g("mu_hat"):
        ctrl["mu_hat"] = float(g("mu_hat"))
    nodes.append(Node(
        package="amr_mpc_cpp", executable="torque_mpc_node", name="torque_mpc_node", output="screen",
        parameters=[ctrl]))

    nodes.append(Node(
        package="amr_mpc", executable="torque_output_node", name="torque_output_node", output="screen"))

    # 위험 감시: 무장 중 포즈 튐·추종 오차·모터 에러·센서 끊김이면 /mpc/arm false → DAMPING
    if source == "estimator":                         # 참값 모드에는 추정기 출력이 없어 끊김으로 오판한다
        nodes.append(Node(
            package="amr_mpc", executable="fault_monitor_node", name="fault_monitor_node", output="screen",
            parameters=[{"max_track_error": float(g("max_track_error"))}]))

    # 슬립률 기록 (로깅 전용). 시뮬이면 참값으로 구한 슬립률도 같이 남긴다
    nodes.append(Node(
        package="amr_mpc", executable="slip_logger_node", name="slip_logger_node", output="screen",
        parameters=[{"body_topic": state_topic,
                     "reference_topic": "/sim/ground_truth" if plant == "sim" else "",
                     "log_prefix": (g("log_prefix") + "_slip") if g("log_prefix") else ""}]))

    # ── 게이트: 무장 전에는 DAMPING 만 나간다. 받는 즉시 중계 (100 Hz 명령을 재샘플하지 않는다)
    nodes.append(Node(
        package="amr_mpc", executable="keyboard_command_gate", name="torque_command_gate", output="screen",
        parameters=[{
            "command_type": "torques",
            "input_topic": "/torque_output/cmd_raw", "output_topic": "/wheel_torque_cmd",
            "arm_topic": "/mpc/arm", "initially_armed": _truthy(g("armed")),
            "keyboard_enabled": True, "command_timeout": 0.20, "publish_frequency": 50.0,
            "forward_on_receive": True,
        }]))
    return nodes


def generate_launch_description():
    share = get_package_share_directory("amr_mpc")
    rviz_cfg = os.path.join(share, "rviz", "torque_experiment.rviz")
    A = DeclareLaunchArgument
    return LaunchDescription([
        A("plant", default_value="sim", choices=["sim", "real"],
          description="sim = sim_plant_torque_node, real = ak40_can_node(7단계)"),
        A("state_source", default_value="estimator", choices=["estimator", "truth"],
          description="estimator = state_estimator_node (SLAM 포즈 + IMU), truth = 시뮬 참값을 바로"),
        A("slam_mode", default_value="scan_time", choices=["scan_time", "extrapolated"],
          description="시뮬 SLAM 꼴. scan_time = 스캔 시각 포즈를 늦게 (외삽 끔), extrapolated = 100 Hz 외삽 스트림 (지금 실차 설정)"),
        A("sensor_noise_scale", default_value="1.0", description="시뮬 센서 잡음 배율 (1 = bag 실측 수준, 0 = 없음)"),
        A("state_topic", default_value="", description="상태 토픽을 직접 줄 때만 (비우면 state_source 에 따라 정한다)"),
        A("max_track_error", default_value="0.30", description="fault_monitor: 기준과 이만큼 벌어지면 정지 [m]"),
        A("surface_mu", default_value="", description="시뮬 바닥 마찰계수 (비우면 슬립 없음). 제어기의 mu_hat 과 따로 준다"),
        A("wheel_odom", default_value="", description="휠 오돔 true/false (비우면 torque_estimator.yaml slam.use_wheel_odom, 기본 false)"),
        A("use_mpc", default_value="true", description="false 면 플랜트(+RViz)만 띄운다"),
        A("use_figure8", default_value="true", description="8자 기준궤적 노드. false 면 기준열을 밖에서 준다"),
        A("armed", default_value="false", description="게이트 초기 상태. false 면 터미널에서 'a' 로 무장"),
        # 모델·비교군. 비우면 config/torque_plant.yaml, torque_mpc.yaml 값
        A("payload_kg", default_value="0.0", description="적재 [kg]. 2차 발표 조건 0 / 5"),
        A("ctrl_payload_kg", default_value="", description="제어기가 믿는 적재. 비우면 payload_kg 와 같게"),
        A("use_wheel_inertia", default_value="", description="모델 바퀴 관성 스위치 (YAML 기본 false)"),
        A("limit_mode", default_value="", description="motor_only(B) | friction(C) (YAML 기본 motor_only)"),
        A("disturbance", default_value="", description="외란 추정치 d̂ true/false (YAML 기본 false)"),
        A("mu_hat", default_value="", description="제어기의 노면 마찰계수 (YAML 기본 0.3)"),
        A("log_prefix", default_value="", description="MPC CSV 접두. 비면 저장 안 함"),
        # 8자 트랙: 비우면 config/torque_track.yaml
        *[A(k, default_value="", description=f"트랙 {k} (비우면 torque_track.yaml)") for k in _TRACK_KEYS],
        A("max_wheel_rad_per_sec", default_value="42.0", description="기준 부하 검사용 바퀴 최고속도 [rad/s] (추정)"),
        A("x0", default_value="0.0"), A("y0", default_value="0.0"), A("yaw0", default_value="0.0"),
        A("use_rviz", default_value="true"),
        OpaqueFunction(function=_nodes),
        Node(package="rviz2", executable="rviz2", name="rviz2", output="log",
             arguments=["-d", rviz_cfg], condition=IfCondition(LaunchConfiguration("use_rviz"))),
    ])
