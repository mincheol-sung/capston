#!/usr/bin/env python3
# 토크 스택 시뮬 플랜트 — 실차 ak40_can_node 와 같은 토픽·타입으로 "가짜 로봇" 노릇을 한다.
# 나중에 실차로 갈 때는 이 노드만 ak40_can_node 로 바꾼다 (토크 MPC 전환 2단계).
#   ros2 run amr_mpc sim_plant_torque_node
# ---------------------------------------------------------------
#   /wheel_torque_cmd   (amr_interfaces/WheelTorqueCommand)  ← 게이트 출력. 실차에서는 ak40_can_node 가 받는다
#      ↓  1판 모델 Ẍ = M⁻¹(R(θ)(T⁻¹)ᵀτ + w)  (amr_mpc/torque/model.py, config/torque_plant.yaml)
#   /wheel_states       (amr_interfaces/WheelStates, 100 Hz)  ← 실차와 같은 토픽. 무슬립 바퀴속도
#   /sim/ground_truth   (nav_msgs/Odometry, 100 Hz)           ← 시뮬 전용 참값. pose = map, twist = 몸체
#   TF map → base_footprint                                   ← RViz 용 (publish_tf)
#
# 명령 처리 (실차 ak40_can_node 도 같은 규칙으로 만든다)
#   MODE_TORQUE   토크를 그대로 낸다. 피크 토크(motor.tau_peak_Nm)로 자른다.
#   MODE_DAMPING  τ = −kd·ω (MIT kp = 0, v = 0, kd = motor.damping_kd). 토크 0 은 관성 주행이라 정지가 아니다.
#   명령 없음 / cmd_timeout 초과 → DAMPING 과 같게 처리한다 (안전 쪽).
#
# 아직 없는 것 (뒤 단계): 슬립, 구동계 마찰, 가짜 /tracked_pose 10 Hz·/camera/imu (4단계 state_estimator 용).
# ---------------------------------------------------------------
import math
import signal

import numpy as np
import rclpy
import rclpy.time
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.signals import SignalHandlerOptions
from tf2_ros import TransformBroadcaster

from amr_interfaces.msg import WheelStates, WheelTorqueCommand
from amr_mpc.torque.model import TorquePlant


class SimPlantTorqueNode(Node):
    def __init__(self):
        super().__init__("sim_plant_torque_node")
        base = TorquePlant.from_yaml()
        self.declare_parameters("", [
            ("cmd_topic", "/wheel_torque_cmd"),
            ("wheel_states_topic", "/wheel_states"),
            ("truth_topic", "/sim/ground_truth"),
            ("map_frame", "map"),
            ("base_frame", "base_footprint"),
            ("publish_tf", True),
            ("rate_hz", 100.0),          # 발행 주기 = 제어 주기 (1판 Ts 10 ms)
            ("substeps", 10),            # 발행 1 주기 안 적분 횟수 (DAMPING 은 ω 에 따라 토크가 바뀌므로 잘게)
            ("cmd_timeout", 0.2),        # 게이트 command_timeout 과 같게
            ("x0", 0.0), ("y0", 0.0), ("yaw0", 0.0),
            # 아래는 비우면 torque_plant.yaml 값. 적재 조건 바꿀 때 launch 인자로 덮어쓴다.
            ("payload_kg", -1.0),
            ("use_wheel_inertia", base.use_wheel_inertia),
        ])
        g = lambda n: self.get_parameter(n).value
        override = {"use_wheel_inertia": bool(g("use_wheel_inertia"))}
        if float(g("payload_kg")) >= 0.0:
            from amr_mpc.core import config
            override["mass"] = float(config.section("body", "torque_plant.yaml")["mass_kg"]) + float(g("payload_kg"))
        self.p = TorquePlant.from_yaml(**override)

        self.X = np.array([g("x0"), g("y0"), g("yaw0")], float)
        self.Xd = np.zeros(3)
        self.wheel_pos = np.zeros(4)
        self.cmd_mode = WheelTorqueCommand.MODE_DAMPING
        self.cmd_tau = np.zeros(4)
        self.last_cmd_t = None
        self.applied = np.zeros(4)
        self.t_last = None

        self.dt = 1.0 / float(g("rate_hz"))
        self.nsub = max(1, int(g("substeps")))
        self.timeout = float(g("cmd_timeout"))
        self.map_frame, self.base_frame = str(g("map_frame")), str(g("base_frame"))

        self.pub_ws = self.create_publisher(WheelStates, str(g("wheel_states_topic")), 10)
        self.pub_truth = self.create_publisher(Odometry, str(g("truth_topic")), 10)
        self.tf = TransformBroadcaster(self) if bool(g("publish_tf")) else None
        self.create_subscription(WheelTorqueCommand, str(g("cmd_topic")), self.on_cmd, 10)
        self.create_timer(self.dt, self.on_tick)
        self.get_logger().info(
            f"시뮬 플랜트: m={self.p.mass:.2f} kg  I_z={self.p.inertia_z:.3f}  "
            f"바퀴관성 {'켬' if self.p.use_wheel_inertia else '끔'} (μ={self.p.mu:.3f} kg)  "
            f"kd={self.p.damping_kd}  피크 {self.p.tau_peak} N·m  {1/self.dt:.0f} Hz")

    def now_s(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_cmd(self, msg):
        self.cmd_mode = int(msg.mode)
        self.cmd_tau = np.clip(np.array(msg.torque, float), -self.p.tau_peak, self.p.tau_peak)
        self.last_cmd_t = self.now_s()

    def _torque(self, X, Xd, damping):
        if damping:
            return np.clip(-self.p.damping_kd * self.p.wheel_speeds(X, Xd), -self.p.tau_peak, self.p.tau_peak)
        return self.cmd_tau

    def on_tick(self):
        # 실제로 흐른 시간만큼 적분한다. 고정 10 ms 로 적분하고 시계 시각을 찍으면, 타이머가 1 ms 흔들릴 때
        # 상태와 stamp 가 1 ms 어긋나 1 m/s 에서 위치가 1 mm 튄 것처럼 보인다 (2026-11-11 폐루프 시험에서 확인).
        now = self.now_s()
        elapsed = self.dt if self.t_last is None else min(max(now - self.t_last, 0.0), 5.0 * self.dt)
        self.t_last = now
        fresh = self.last_cmd_t is not None and now - self.last_cmd_t <= self.timeout
        damping = (not fresh) or self.cmd_mode != WheelTorqueCommand.MODE_TORQUE
        h = elapsed / self.nsub
        for _ in range(self.nsub):
            tau = self._torque(self.X, self.Xd, damping)
            w_before = self.p.wheel_speeds(self.X, self.Xd)
            self.X, self.Xd = self.p.step(self.X, self.Xd, tau, h)
            self.wheel_pos += 0.5 * h * (w_before + self.p.wheel_speeds(self.X, self.Xd))
        self.applied = tau
        self.publish(rclpy.time.Time(nanoseconds=int(round(now * 1e9)), clock_type=self.get_clock().clock_type).to_msg())

    def publish(self, stamp):
        wheel_w = self.p.wheel_speeds(self.X, self.Xd)

        ws = WheelStates()
        ws.header.stamp = stamp
        ws.header.frame_id = self.base_frame
        ws.position = [float(v) for v in self.wheel_pos]
        ws.velocity = [float(v) for v in wheel_w]
        ws.torque = [float(v) for v in self.applied]
        ws.temperature = [float("nan")] * 4
        ws.error = [0, 0, 0, 0]
        ws.fresh = [True] * 4
        self.pub_ws.publish(ws)

        qz, qw = math.sin(self.X[2] / 2), math.cos(self.X[2] / 2)
        o = Odometry()
        o.header.stamp = stamp
        o.header.frame_id = self.map_frame
        o.child_frame_id = self.base_frame
        o.pose.pose.position.x, o.pose.pose.position.y = float(self.X[0]), float(self.X[1])
        o.pose.pose.orientation.z, o.pose.pose.orientation.w = qz, qw
        vb = self.p.body_velocity(self.X, self.Xd)
        o.twist.twist.linear.x, o.twist.twist.linear.y, o.twist.twist.angular.z = map(float, vb)
        self.pub_truth.publish(o)

        if self.tf is not None:
            t = TransformStamped()
            t.header.stamp = stamp
            t.header.frame_id = self.map_frame
            t.child_frame_id = self.base_frame
            t.transform.translation.x, t.transform.translation.y = float(self.X[0]), float(self.X[1])
            t.transform.rotation.z, t.transform.rotation.w = qz, qw
            self.tf.sendTransform(t)


def main():
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = SimPlantTorqueNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        try:
            node.destroy_node()
        except Exception:
            pass
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
