#!/usr/bin/env python3
"""토크 MPC 실험 launch (구조도 v3) — 기존 autonomy.launch.py 와 별개다.

기존 스택(RoboClaw, EKF, DRA-MPPI, 인지)은 띄우지 않는다. 기존 경로는 그대로 남겨 둔다.
단계별로 노드가 늘어난다 (amr/notes_amr/stack_changelog.md, torque_mpc_todo.md).

  지금 (3단계) — 시뮬 폐루프:
    figure8_reference_node ─기준열─▶ torque_mpc_node ─▶ torque_output_node ─▶ 게이트('a' 무장) ─▶ sim_plant_torque_node
                                          ▲                                                          │
                                          └────────── 상태 (지금은 시뮬 참값 /sim/ground_truth) ◀─────┘
  4단계:  상태를 state_estimator 로 (state_topic:=/state_estimator/odom)
  7단계:  plant:=real → ak40_can_node + 센서·Cartographer

사용 (새 터미널에서 amr 을 먼저)
  ros2 launch amr_mpc torque_experiment.launch.py                       # 8자 한 바퀴. 이 터미널에서 a = 무장, s/SPACE = 정지
  ros2 launch amr_mpc torque_experiment.launch.py armed:=true           # 띄우자마자 무장 (시뮬에서만)
  ros2 launch amr_mpc torque_experiment.launch.py limit_mode:=friction  # 비교군 C (마찰 토크 상한). 기본 motor_only = B
  ros2 launch amr_mpc torque_experiment.launch.py disturbance:=true     # 외란 추정치 d̂ 켬 (기본 끔)
  ros2 launch amr_mpc torque_experiment.launch.py payload_kg:=5.0       # 적재 +5 kg (플랜트와 제어기 둘 다)
  ros2 launch amr_mpc torque_experiment.launch.py payload_kg:=5.0 ctrl_payload_kg:=0.0   # 제어기는 모름 (질량 오차 시험)
  ros2 launch amr_mpc torque_experiment.launch.py use_mpc:=false        # 플랜트·RViz 만 (손으로 토크 주기, tools/torque_demo_drive.py)
  8자 모양·속도: width:=3.0 height:=1.5 speed:=0.5 laps:=2

비워 두는 인자(limit_mode, disturbance, use_wheel_inertia, ctrl_payload_kg)는 config/*.yaml 값을 쓴다.
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo, OpaqueFunction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _truthy(s):
    return str(s).strip().lower() in ("true", "1", "yes", "on")


def _nodes(context):
    g = lambda n: LaunchConfiguration(n).perform(context).strip()
    plant, state_topic = g("plant"), g("state_topic")
    nodes = []

    # 플랜트와 제어기가 같이 쓰는 모델 설정. 비어 있으면 YAML 값
    shared = {}
    if g("use_wheel_inertia"):
        shared["use_wheel_inertia"] = _truthy(g("use_wheel_inertia"))
    payload = float(g("payload_kg"))

    # ── 플랜트
    if plant == "sim":
        nodes.append(Node(
            package="amr_mpc", executable="sim_plant_torque_node", name="sim_plant_torque_node", output="screen",
            parameters=[{**shared, "payload_kg": payload,
                         "x0": float(g("x0")), "y0": float(g("y0")), "yaw0": float(g("yaw0"))}]))
    elif plant == "real":
        nodes.append(LogInfo(msg="plant:=real 은 아직 없다 (7단계 ak40_can_node). 아무 플랜트도 띄우지 않는다."))
    else:
        raise RuntimeError(f"plant:={plant!r} — sim 또는 real")

    if not _truthy(g("use_mpc")):
        return nodes

    # ── 기준궤적: 8자 시간 기준 (기동 포즈가 교차점)
    if _truthy(g("use_figure8")):
        nodes.append(Node(
            package="amr_mpc", executable="figure8_reference_node", name="figure8_reference_node", output="screen",
            parameters=[{
                "width": float(g("width")), "height": float(g("height")), "speed": float(g("speed")),
                "accel": float(g("accel")), "laps": float(g("laps")), "yaw_mode": g("yaw_mode"),
                "align_s": float(g("align_s")), "start_delay": float(g("start_delay")),
                "abort_error": float(g("abort_error")), "hold_s": float(g("hold_s")),
                "frame_id": "map", "odom_topic": state_topic,
                # 기준 부하 검사용 바퀴 최고속도. AK40-10 무부하 추정 402 rpm = 42 rad/s (22.2 V, 미실측 — To do 1절)
                "max_wheel_rad_per_sec": float(g("max_wheel_rad_per_sec")),
            }]))

    # ── 제어기. payload_kg 는 "제어기가 믿는" 적재 (비우면 플랜트와 같게)
    ctrl = {**shared, "state_topic": state_topic,
            "payload_kg": float(g("ctrl_payload_kg")) if g("ctrl_payload_kg") else payload,
            "log_prefix": g("log_prefix")}
    if g("limit_mode"):
        ctrl["limit_mode"] = g("limit_mode")
    if g("disturbance"):
        ctrl["disturbance_enable"] = _truthy(g("disturbance"))
    if g("mu_hat"):
        ctrl["mu_hat"] = float(g("mu_hat"))
    nodes.append(Node(
        package="amr_mpc_cpp", executable="torque_mpc_node", name="torque_mpc_node", output="screen",
        parameters=[ctrl]))

    nodes.append(Node(
        package="amr_mpc", executable="torque_output_node", name="torque_output_node", output="screen"))

    # ── 게이트: 무장 전에는 DAMPING 만 나간다. 받는 즉시 중계 (100 Hz 명령을 재샘플하지 않는다)
    nodes.append(Node(
        package="amr_mpc", executable="keyboard_command_gate", name="torque_command_gate", output="screen",
        parameters=[{
            "command_type": "torques",
            "input_topic": "/torque_output/cmd_raw", "output_topic": "/wheel_torque_cmd",
            "arm_topic": "/mpc/arm", "initially_armed": _truthy(g("armed")),
            "keyboard_enabled": True, "command_timeout": 0.20, "publish_frequency": 50.0,
            "forward_on_receive": True,
        }]))
    return nodes


def generate_launch_description():
    share = get_package_share_directory("amr_mpc")
    rviz_cfg = os.path.join(share, "rviz", "torque_experiment.rviz")
    A = DeclareLaunchArgument
    return LaunchDescription([
        A("plant", default_value="sim", choices=["sim", "real"],
          description="sim = sim_plant_torque_node, real = ak40_can_node(7단계)"),
        A("state_topic", default_value="/sim/ground_truth",
          description="MPC·기준궤적이 쓰는 상태(Odometry). 3단계는 시뮬 참값, 4단계부터 /state_estimator/odom"),
        A("use_mpc", default_value="true", description="false 면 플랜트(+RViz)만 띄운다"),
        A("use_figure8", default_value="true", description="8자 기준궤적 노드. false 면 기준열을 밖에서 준다"),
        A("armed", default_value="false", description="게이트 초기 상태. false 면 터미널에서 'a' 로 무장"),
        # 모델·비교군. 비우면 config/torque_plant.yaml, torque_mpc.yaml 값
        A("payload_kg", default_value="0.0", description="적재 [kg]. 2차 발표 조건 0 / 5"),
        A("ctrl_payload_kg", default_value="", description="제어기가 믿는 적재. 비우면 payload_kg 와 같게"),
        A("use_wheel_inertia", default_value="", description="모델 바퀴 관성 스위치 (YAML 기본 false)"),
        A("limit_mode", default_value="", description="motor_only(B) | friction(C) (YAML 기본 motor_only)"),
        A("disturbance", default_value="", description="외란 추정치 d̂ true/false (YAML 기본 false)"),
        A("mu_hat", default_value="", description="제어기의 노면 마찰계수 (YAML 기본 0.3)"),
        A("log_prefix", default_value="", description="MPC CSV 접두. 비면 저장 안 함"),
        # 8자
        A("width", default_value="1.4", description="8자 가로 [m]"),
        A("height", default_value="0.8", description="8자 세로 [m]"),
        A("speed", default_value="0.25", description="순항 속도 [m/s]"),
        A("accel", default_value="0.4", description="가감속 [m/s²]"),
        A("laps", default_value="1.0"),
        A("yaw_mode", default_value="tangent", description="tangent | fixed"),
        A("align_s", default_value="1.5", description="앞뒤 제자리 회전 시간 [s]"),
        A("start_delay", default_value="3.0", description="첫 상태 수신 뒤 출발까지 [s]"),
        A("abort_error", default_value="0.35", description="기준에서 이만큼 벗어나면 중단 [m]"),
        A("hold_s", default_value="5.0"),
        A("max_wheel_rad_per_sec", default_value="42.0", description="기준 부하 검사용 바퀴 최고속도 [rad/s] (추정)"),
        A("x0", default_value="0.0"), A("y0", default_value="0.0"), A("yaw0", default_value="0.0"),
        A("use_rviz", default_value="true"),
        OpaqueFunction(function=_nodes),
        Node(package="rviz2", executable="rviz2", name="rviz2", output="log",
             arguments=["-d", rviz_cfg], condition=IfCondition(LaunchConfiguration("use_rviz"))),
    ])
