#!/usr/bin/env python3
"""AK40-10 MIT 모드 CAN 메시지 — 만들기·풀기. ROS·소켓에 의존하지 않는다 (단위 시험 test/test_ak40_protocol.py).

CubeMars AK 시리즈 MIT 모드는 MIT Mini Cheetah 드라이버(Ben Katz) 규약을 따른다. 11 비트 표준 ID, 8 바이트.
★ 범위(P/V/T/KP/KD 최댓값)·응답 길이·온도 오프셋은 모델·펌웨어마다 다르다. config/ak40.yaml 의 값은
  AK40-10 매뉴얼로 아직 확인하지 않은 값이다 (verified: false). 확인 전에는 ak40_can_node 가 실제 버스에서 시작을 거부한다.

특수 명령 (ID = 모터 ID)
  모터 모드 들어가기  FF FF FF FF FF FF FF FC     나오기  … FD     현재 위치를 0 으로  … FE

명령 (ID = 모터 ID) — 모터는 τ = kp·(p_des − p) + kd·(v_des − v) + t_ff 를 낸다
  p_des 16 비트 | v_des 12 | kp 12 | kd 12 | t_ff 12
  [0] p>>8  [1] p&FF  [2] v>>4  [3] (v&F)<<4 | kp>>8  [4] kp&FF  [5] kd>>4  [6] (kd&F)<<4 | t>>8  [7] t&FF
  우리 쓰임:  MODE_TORQUE  → kp = 0, kd = 0, t_ff = τ        (WheelTorqueCommand.msg)
              MODE_DAMPING → kp = 0, v_des = 0, kd = damping_kd, t_ff = 0

응답 (모터가 명령마다 하나, ID 는 마스터 ID — 모터 ID 는 [0])
  [0] 모터 ID  [1..2] p 16 비트  [3] v>>4  [4] (v&F)<<4 | t>>8  [5] t&FF  [6] 온도 (+오프셋)  [7] 에러 코드
  6 바이트 펌웨어는 [6][7] 이 없다 (온도 NaN, 에러 0 으로 둔다).

정수 변환: 원본 C 코드는 버림((int))이라 토크가 늘 반 칸 음수 쪽으로 치우친다. 우리가 보내는 쪽은 반올림한다.
  (T ±10 N·m 가정이면 한 칸 0.0049 N·m — 비교군 C 의 상한 0.067 N·m 에 견주면 7 %. 버림이면 평균 −0.0024 N·m 치우침)
"""
from dataclasses import dataclass
import math

ENTER_MOTOR_MODE = bytes([0xFF] * 7 + [0xFC])
EXIT_MOTOR_MODE = bytes([0xFF] * 7 + [0xFD])
SET_ZERO = bytes([0xFF] * 7 + [0xFE])
SPECIAL = {ENTER_MOTOR_MODE: "enter", EXIT_MOTOR_MODE: "exit", SET_ZERO: "zero"}


@dataclass(frozen=True)
class MitLimits:
    p_max: float = 12.5      # [rad]   위치 ±
    v_max: float = 50.0      # [rad/s] 속도 ±
    t_max: float = 10.0      # [N·m]   토크 ±
    kp_max: float = 500.0    # kp 0 … 이 값
    kd_max: float = 5.0      # kd 0 … 이 값

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: float(d[k]) for k in cls.__dataclass_fields__ if k in d})

    def step(self, name):
        """그 필드 정수 한 칸의 크기 (12/16 비트)."""
        span, bits = {"p": (2 * self.p_max, 16), "v": (2 * self.v_max, 12), "t": (2 * self.t_max, 12),
                      "kp": (self.kp_max, 12), "kd": (self.kd_max, 12)}[name]
        return span / ((1 << bits) - 1)


def float_to_uint(x, lo, hi, bits):
    """[lo, hi] → 0 … 2^bits − 1, 반올림. 범위 밖은 끝으로 자른다."""
    x = min(max(float(x), lo), hi)
    n = (1 << bits) - 1
    return int(round((x - lo) * n / (hi - lo)))


def uint_to_float(u, lo, hi, bits):
    return lo + (hi - lo) * float(u) / ((1 << bits) - 1)


def pack_command(lim, p, v, kp, kd, t):
    """MIT 명령 8 바이트."""
    pi = float_to_uint(p, -lim.p_max, lim.p_max, 16)
    vi = float_to_uint(v, -lim.v_max, lim.v_max, 12)
    kpi = float_to_uint(kp, 0.0, lim.kp_max, 12)
    kdi = float_to_uint(kd, 0.0, lim.kd_max, 12)
    ti = float_to_uint(t, -lim.t_max, lim.t_max, 12)
    return bytes([pi >> 8, pi & 0xFF, vi >> 4, ((vi & 0xF) << 4) | (kpi >> 8), kpi & 0xFF,
                  kdi >> 4, ((kdi & 0xF) << 4) | (ti >> 8), ti & 0xFF])


def unpack_command(lim, data):
    """pack_command 의 역 (가짜 모터가 쓴다). 반환 (p, v, kp, kd, t)."""
    d = data
    pi = (d[0] << 8) | d[1]
    vi = (d[2] << 4) | (d[3] >> 4)
    kpi = ((d[3] & 0xF) << 8) | d[4]
    kdi = (d[5] << 4) | (d[6] >> 4)
    ti = ((d[6] & 0xF) << 8) | d[7]
    return (uint_to_float(pi, -lim.p_max, lim.p_max, 16), uint_to_float(vi, -lim.v_max, lim.v_max, 12),
            uint_to_float(kpi, 0.0, lim.kp_max, 12), uint_to_float(kdi, 0.0, lim.kd_max, 12),
            uint_to_float(ti, -lim.t_max, lim.t_max, 12))


def pack_reply(lim, motor_id, p, v, t, temp_c=25.0, error=0, length=8, temp_offset=40):
    """모터 응답 (가짜 모터가 쓴다)."""
    pi = float_to_uint(p, -lim.p_max, lim.p_max, 16)
    vi = float_to_uint(v, -lim.v_max, lim.v_max, 12)
    ti = float_to_uint(t, -lim.t_max, lim.t_max, 12)
    out = [motor_id & 0xFF, pi >> 8, pi & 0xFF, vi >> 4, ((vi & 0xF) << 4) | (ti >> 8), ti & 0xFF]
    if length >= 8:
        out += [int(min(max(round(temp_c + temp_offset), 0), 255)), int(error) & 0xFF]
    return bytes(out)


def unpack_reply(lim, data, temp_offset=40):
    """모터 응답 → dict(id, p, v, t, temp, error). 6 바이트면 temp NaN, error 0."""
    d = data
    if len(d) < 6:
        raise ValueError(f"응답이 {len(d)} 바이트 — 6 이상이어야 한다")
    pi = (d[1] << 8) | d[2]
    vi = (d[3] << 4) | (d[4] >> 4)
    ti = ((d[4] & 0xF) << 8) | d[5]
    return {
        "id": d[0],
        "p": uint_to_float(pi, -lim.p_max, lim.p_max, 16),
        "v": uint_to_float(vi, -lim.v_max, lim.v_max, 12),
        "t": uint_to_float(ti, -lim.t_max, lim.t_max, 12),
        "temp": float(d[6] - temp_offset) if len(d) >= 8 else math.nan,
        "error": int(d[7]) if len(d) >= 8 else 0,
    }


def wrap_position(p, lim):
    """모터가 내는 위치는 ±p_max 에서 돈다 (가짜 모터용)."""
    span = 2.0 * lim.p_max
    return (p + lim.p_max) % span - lim.p_max


class PositionUnwrapper:
    """±p_max 에서 도는 위치를 펼친 누적값으로. 한 주기 변화가 반 바퀴(p_max)보다 크면 넘어간 것으로 본다.
    100 Hz 에서 p_max 12.5 rad 면 1250 rad/s 까지 안전 (모터 최고속도 약 42 rad/s)."""

    def __init__(self, lim):
        self.span = 2.0 * lim.p_max
        self.half = lim.p_max
        self.last = None
        self.turns = 0

    def update(self, p):
        if self.last is not None:
            dp = p - self.last
            if dp > self.half:
                self.turns -= 1
            elif dp < -self.half:
                self.turns += 1
        self.last = p
        return p + self.turns * self.span
