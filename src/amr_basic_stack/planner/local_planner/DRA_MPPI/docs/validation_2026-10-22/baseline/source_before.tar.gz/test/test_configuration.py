from pathlib import Path

import yaml


def test_controller_period_matches_one_mppi_warm_start_step():
    config_path = Path(__file__).parents[1] / 'config' / 'dra_mppi.yaml'
    parameters = yaml.safe_load(config_path.read_text())['dra_mppi_node'][
        'ros__parameters'
    ]

    controller_period = 1.0 / float(parameters['controller_frequency'])
    assert controller_period == float(parameters['mppi.dt'])


def test_guide_budget_is_independent_of_standard_budget():
    config_path = Path(__file__).parents[1] / 'config' / 'dra_mppi.yaml'
    p = yaml.safe_load(config_path.read_text())['dra_mppi_node']['ros__parameters']
    assert p['mppi.guide_num_rollouts'] == 500
    assert p['mppi.guide_angles_deg'] == [0.0, 45.0, 90.0, -45.0, -90.0]
    assert p['mppi.num_rollouts'] == 321
    assert p['traversability.unknown_is_obstacle'] is True
    assert p['dynamic_risk.guide_parallel_workers'] == 2
    assert p['dynamic_risk.guide_mc_sample_density'] == 124.0
    assert p['dynamic_risk.guide_mc_samples_min'] == 128
    assert p['dynamic_risk.guide_mc_samples_max'] == 1024
    assert p['dynamic_risk.final_mc_sample_density'] == 124.0
    assert p['dynamic_risk.final_mc_samples_min'] == 256
    assert p['dynamic_risk.final_mc_samples_max'] == 4096


def test_static_cost_is_explicitly_switchable():
    config_path = Path(__file__).parents[1] / 'config' / 'dra_mppi.yaml'
    p = yaml.safe_load(config_path.read_text())['dra_mppi_node']['ros__parameters']

    assert isinstance(p['static_cost.enabled'], bool)
    assert p['static_cost.enabled'] is True
    assert p['static_cost.soft_weight'] >= 0.0
    assert p['static_cost.decay'] > 0.0
