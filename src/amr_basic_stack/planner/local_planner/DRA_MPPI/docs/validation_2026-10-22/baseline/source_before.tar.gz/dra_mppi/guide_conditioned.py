"""Robot-relative anchor ensembles using the existing Halton MPPI sampler.

Motion-primitive sampling is deliberately not part of this implementation.
Primary risk quadrature uses one local domain per guide.  A small persistent
worker pool evaluates those domains in parallel, then all final guide
representatives and Stop receive one common higher-density risk evaluation.
Optional traversability-map costs are evaluated per rollout and again on the
final guide representatives and independent braking candidate.
"""

from concurrent.futures import ThreadPoolExecutor
import time

import numpy as np

from .control_sampling import HaltonSplineSampler
from .dynamic_risk import (
    MonteCarloDiagnostics,
    MonteCarloJointCollisionProbability,
)
from .geometry import wrap_angle
from .mecanum_model import rollout
from .mppi_controller import MppiCostTerms, MppiResult


class GuideConditionedOptimizer:
    def __init__(self, controller):
        self.controller = controller
        self.cfg = cfg = controller.config
        self.angles = np.asarray(cfg.guide_angles_deg, dtype=float)
        if (self.angles.ndim != 1 or not self.angles.size
                or not np.all(np.isfinite(self.angles))
                or len(np.unique(self.angles % 360)) != self.angles.size):
            raise ValueError('guide angles must be finite and distinct')
        self.count = len(self.angles)
        if cfg.guide_num_rollouts < 2 * self.count:
            raise ValueError('guide_num_rollouts must reserve two samples per guide')
        if not 0.0 <= cfg.guide_anchor_blend <= 1.0:
            raise ValueError('guide_anchor_blend must be in [0,1]')
        if not np.all(np.isfinite([
                cfg.guide_anchor_blend, cfg.guide_switch_penalty,
                cfg.guide_hysteresis])) or min(
                cfg.guide_switch_penalty, cfg.guide_hysteresis) < 0:
            raise ValueError('guide penalties must be finite and nonnegative')
        std = np.asarray(cfg.guide_noise_std, dtype=float)
        if std.shape != (3,) or not np.all(np.isfinite(std)) or np.any(std < 0):
            raise ValueError('guide_noise_std must be three finite nonnegative values')
        # Independent deterministic bases; truncate to the allocated budget.
        self.noise = [HaltonSplineSampler(
            cfg.horizon_steps, knot_points=cfg.spline_knots,
            noise_std=std, scramble=cfg.halton_scramble, seed=cfg.seed + 101 + g,
        ).sample(cfg.guide_num_rollouts - 2) for g in range(self.count)]
        risk = cfg.dynamic_risk
        self.risk_workers = min(int(risk.guide_parallel_workers), self.count)
        self._risk_executor = (
            ThreadPoolExecutor(
                max_workers=self.risk_workers,
                thread_name_prefix='dra_mppi_guide_risk',
            )
            if self.risk_workers > 1 else None
        )
        self._guide_risk_estimators = [
            MonteCarloJointCollisionProbability(
                num_samples=risk.guide_mc_samples_min,
                minimum_sigma=risk.minimum_sigma,
                seed=risk.seed + 1009 + g,
                adaptive_halton=risk.adaptive_halton_mc,
                sample_density=risk.guide_mc_sample_density,
                min_samples=risk.guide_mc_samples_min,
                max_samples=risk.guide_mc_samples_max,
            )
            for g in range(self.count)
        ]
        self._final_risk_estimator = MonteCarloJointCollisionProbability(
            num_samples=risk.final_mc_samples_min,
            minimum_sigma=risk.minimum_sigma,
            seed=risk.seed + 2003,
            adaptive_halton=risk.adaptive_halton_mc,
            sample_density=risk.final_mc_sample_density,
            min_samples=risk.final_mc_samples_min,
            max_samples=risk.final_mc_samples_max,
        )
        self.names = tuple(f'guide_{a:+g}' for a in self.angles) + ('stop',)
        self.reset()

    def reset(self):
        self.nominals = np.zeros((self.count, self.cfg.horizon_steps, 3))
        self.temperatures = np.full(self.count, self.cfg.temperature, dtype=float)
        self.initialized = np.zeros(self.count, dtype=bool)
        self.previous = None
        self.entry_yaw = None
        self.allocation_offset = 0

    def constrain(self, controls, current):
        """Joint box/wheel/rate feasibility shared with the standard strategy.

        Both endpoints lie in the convex box/wheel polytope. Interpolate toward
        each desired input just far enough to satisfy every acceleration bound.
        If measured velocity is already infeasible, wheel feasibility wins on
        the initial projection; a velocity-reference planner cannot undo it.
        """
        return self.controller._constrain_controls(controls, current)

    def anchors(self, state, path, current, goal=None):
        """Fixed world translation rays; yaw independently follows path tangent."""
        c, cfg = self.controller, self.cfg
        headings = state[2] + np.deg2rad(self.angles)
        directions = np.column_stack((np.cos(headings), np.sin(headings)))
        states = np.broadcast_to(state, (self.count, 3)).copy()
        previous = np.broadcast_to(current, (self.count, 3)).copy()
        controls = np.zeros((self.count, cfg.horizon_steps, 3))
        for t in range(cfg.horizon_steps):
            tangent = c._nearest_path_geometry(states[:, None, :], path)[3][:, 0]
            yaw_rate = np.clip(wrap_angle(tangent - states[:, 2]) / cfg.dt,
                               c._control_min[2], c._control_max[2])
            cos, sin = np.cos(states[:, 2]), np.sin(states[:, 2])
            body_direction = np.column_stack((
                cos * directions[:, 0] + sin * directions[:, 1],
                -sin * directions[:, 0] + cos * directions[:, 1]))
            axis_limit = np.where(body_direction >= 0,
                                  c._control_max[:2], -c._control_min[:2])
            axis_speed = np.divide(axis_limit, np.abs(body_direction),
                                   out=np.full_like(body_direction, np.inf),
                                   where=np.abs(body_direction) > 1e-12)
            # Translation and rotation share the wheel load. Projection below
            # handles yaw demand; the direction-speed cap handles translation.
            speed = np.minimum(cfg.desired_speed, np.minimum(
                np.min(axis_speed, axis=1),
                cfg.speed_limit_l1 / np.sum(np.abs(body_direction), axis=1)))
            if goal is not None:
                distance = np.linalg.norm(states[:, :2] - goal, axis=1)
                braking = np.sqrt(2.0 * np.min(c._acceleration_limit[:2]) * distance)
                speed = np.minimum(speed, np.minimum(braking, distance / cfg.dt))
            raw = np.column_stack((body_direction * speed[:, None], yaw_rate))
            # Per-guide current velocities, after the first step.
            for g in range(self.count):
                controls[g, t] = self.constrain(raw[g:g+1, None], previous[g])[0, 0]
                states[g] = rollout(states[g], controls[g, t:t+1], cfg.dt)[0]
            previous = controls[:, t]
        return controls

    def allocate(self, active):
        ids = np.flatnonzero(active)
        counts = np.zeros(self.count, dtype=int)
        if ids.size:
            base, remainder = divmod(self.cfg.guide_num_rollouts, len(ids))
            counts[ids] = base
            order = np.roll(ids, -(self.allocation_offset % len(ids)))
            counts[order[:remainder]] += 1
            self.allocation_offset += 1
        return counts

    def shutdown(self):
        if self._risk_executor is not None:
            self._risk_executor.shutdown(wait=True, cancel_futures=True)
            self._risk_executor = None

    @staticmethod
    def _aggregate_risk_diagnostics(diagnostics, horizon, elapsed_ms):
        """Combine per-guide work while retaining each guide/time matrix."""
        guide_count = len(diagnostics)
        areas = np.zeros((guide_count, horizon), dtype=np.float64)
        samples = np.zeros((guide_count, horizon), dtype=np.int64)
        for guide, item in enumerate(diagnostics):
            if item.region_areas.size:
                areas[guide] = item.region_areas
                samples[guide] = item.sample_counts
        finite_minima = [
            item.raw_marginal_minimum for item in diagnostics
            if np.isfinite(item.raw_marginal_minimum)
        ]
        finite_maxima = [
            item.raw_marginal_maximum for item in diagnostics
            if np.isfinite(item.raw_marginal_maximum)
        ]
        active = [item for item in diagnostics if item.sample_counts.size]
        aggregate = MonteCarloDiagnostics(
            sampling_mode=(
                f'per_guide_{active[0].sampling_mode}'
                if active else diagnostics[0].sampling_mode
            ),
            region_areas=np.sum(areas, axis=0) if active else np.empty(0),
            sample_counts=np.sum(samples, axis=0) if active else np.empty(0, dtype=np.int64),
            total_samples=int(np.sum(samples)),
            compute_time_ms=float(elapsed_ms),
            empty_circle_count=sum(item.empty_circle_count for item in diagnostics),
            clipped_marginal_count=sum(
                item.clipped_marginal_count for item in diagnostics),
            raw_marginal_minimum=(min(finite_minima) if finite_minima else 0.0),
            raw_marginal_maximum=(max(finite_maxima) if finite_maxima else 0.0),
        )
        return aggregate, areas, samples

    def _evaluate_guide_risk(self, trajectories, slices, predictions):
        c, cfg = self.controller, self.cfg
        horizon = cfg.horizon_steps
        risk_cost = np.zeros(len(trajectories), dtype=np.float64)
        probabilities = np.zeros((len(trajectories), horizon), dtype=np.float64)
        radii = (
            cfg.dynamic_risk.robot_radius + predictions.obstacle_radii
            if (predictions is not None and not predictions.empty
                and predictions.obstacle_radii is not None)
            else np.array([
                cfg.dynamic_risk.robot_radius
                + cfg.dynamic_risk.obstacle_radius
            ])
        )
        maximum_radius = float(np.max(radii))
        planned_areas = np.zeros((self.count, horizon), dtype=np.float64)
        planned_samples = np.zeros((self.count, horizon), dtype=np.int64)
        for guide, group in enumerate(slices):
            if group.stop <= group.start:
                continue
            centers = trajectories[group, :, :2]
            lower = np.min(centers, axis=0) - maximum_radius
            upper = np.max(centers, axis=0) + maximum_radius
            planned_areas[guide] = np.prod(upper - lower, axis=1)
            planned_samples[guide] = [
                self._guide_risk_estimators[guide]._sample_count(area)
                for area in planned_areas[guide]
            ]
        has_risk = (
            predictions is not None
            and not predictions.empty
            and cfg.dynamic_risk.mode != 'off'
        )
        started = time.perf_counter()
        if has_risk:
            jobs = [
                (g, group) for g, group in enumerate(slices)
                if group.stop > group.start
            ]

            def evaluate(job):
                guide, group = job
                return guide, c._evaluate_dynamic_risk(
                    trajectories[group],
                    predictions,
                    estimator=self._guide_risk_estimators[guide],
                )

            evaluated = (
                list(self._risk_executor.map(evaluate, jobs))
                if self._risk_executor is not None else [evaluate(job) for job in jobs]
            )
            for guide, result in evaluated:
                group = slices[guide]
                risk_cost[group] = result.cost
                probabilities[group] = result.collision_probability
        else:
            for estimator in self._guide_risk_estimators:
                estimator.reset_diagnostics()
        elapsed_ms = (
            (time.perf_counter() - started) * 1000.0 if has_risk else 0.0
        )
        diagnostics = [
            estimator.last_diagnostics for estimator in self._guide_risk_estimators
        ]
        aggregate, areas, samples = self._aggregate_risk_diagnostics(
            diagnostics, horizon, elapsed_ms)
        if not has_risk:
            # Geometry is still published so a bag without accepted people can
            # show the MC budget that would have been used.
            areas = planned_areas
            samples = planned_samples
        c._risk_estimator.last_diagnostics = aggregate
        return risk_cost, probabilities, aggregate, areas, samples

    def compute(self, state, path, current, predictions, visual_count,
                field, transform, started, goal=None):
        if not np.all(np.isfinite(np.r_[state, current, path.ravel()])):
            raise ValueError('guide input must be finite')
        c, cfg = self.controller, self.cfg
        anchors = self.anchors(state, path, current, goal)
        anchor_paths = rollout(state, anchors, cfg.dt)

        # Keep all directional proposals; common evaluation masks individual
        # colliding samples when static_cost.enabled is true.
        active = np.ones(self.count, dtype=bool)
        counts = self.allocate(active)
        # Body-relative IDs can change world direction after a large yaw jump.
        if (self.entry_yaw is not None
                and abs(wrap_angle(state[2] - self.entry_yaw)) > np.deg2rad(30)):
            self.initialized[:] = False
            self.previous = None
        self.entry_yaw = float(state[2])
        temperatures = self.temperatures.copy()
        controls = np.empty((int(counts.sum()), cfg.horizon_steps, 3))
        ids = np.repeat(np.arange(self.count), counts)
        slices, offset = [], 0
        for g, n in enumerate(counts):
            group = slice(offset, offset + n)
            slices.append(group)
            if n:
                center = anchors[g]
                if self.initialized[g]:
                    center = ((1 - cfg.guide_anchor_blend) * self.nominals[g]
                              + cfg.guide_anchor_blend * anchors[g])
                controls[offset] = center
                controls[offset + 1] = anchors[g]
                controls[offset + 2:offset + n] = center + self.noise[g][:n - 2]
            offset += n
        controls = self.constrain(controls, current)
        trajectories = rollout(state, controls, cfg.dt)
        if len(controls):
            # Geometry/static terms stay in one vectorized batch. Dynamic risk
            # alone is split into guide-local spatial domains.
            base_terms, _ = c._evaluate_rollouts(
                state, path, controls, trajectories, None,
                distance_field=field, source_to_grid=transform,
            )
            risk_cost, probabilities, primary_diagnostics, guide_areas, guide_samples = (
                self._evaluate_guide_risk(trajectories, slices, predictions)
            )
            terms = MppiCostTerms(
                tracking=base_terms.tracking,
                heading=base_terms.heading,
                speed=base_terms.speed,
                rotation=base_terms.rotation,
                risk=risk_cost,
                static=base_terms.static,
            )
        else:
            terms = MppiCostTerms(*(np.empty(0) for _ in range(6)))
            probabilities = np.empty((0, cfg.horizon_steps))
            for estimator in self._guide_risk_estimators:
                estimator.reset_diagnostics()
            primary_diagnostics, guide_areas, guide_samples = (
                self._aggregate_risk_diagnostics(
                    [e.last_diagnostics for e in self._guide_risk_estimators],
                    cfg.horizon_steps,
                    0.0,
                )
            )
            c._risk_estimator.last_diagnostics = primary_diagnostics
        costs = terms.total
        weights = np.zeros(len(controls))
        representatives = anchors.copy()
        valid = np.zeros(self.count, dtype=bool)
        ess, normalizers = np.zeros(self.count), np.zeros(self.count)
        reasons = [''] * self.count
        for g, group in enumerate(slices):
            if not counts[g]:
                continue
            data = c._importance_weights(costs[group], temperatures[g])
            if data is None:
                reasons[g] = 'all_samples_invalid'
                self.initialized[g] = False
                continue
            w, normalizer = data[3:]
            weights[group] = w
            representatives[g] = np.sum(w[:, None, None] * controls[group], axis=0)
            valid[g] = True
            ess[g] = 1.0 / np.sum(w * w)
            normalizers[g] = normalizer
            self.temperatures[g] = c._adapt_temperature(temperatures[g], normalizer)
        representatives = self.constrain(representatives, current)
        # Evaluate valid representatives and a separate acceleration-limited
        # stopping trajectory derived from the measured current velocity.
        final_ids = np.r_[np.flatnonzero(valid), self.count]
        stopping_control = c._make_stopping_control(current)
        all_controls = np.concatenate((representatives,
                                       stopping_control[None, ...]))
        all_paths = rollout(state, all_controls, cfg.dt)
        final_started = time.perf_counter()
        final_terms, final_risk = c._evaluate_rollouts(
            state, path, all_controls[final_ids], all_paths[final_ids], predictions,
            distance_field=field, source_to_grid=transform,
            risk_estimator=self._final_risk_estimator)
        final_diagnostics = self._final_risk_estimator.last_diagnostics
        final_static = np.zeros(self.count + 1, dtype=bool)
        if final_terms.static is not None:
            final_static[final_ids] = np.isinf(final_terms.static)
        c.representative_time_ms = (time.perf_counter()-final_started)*1000.
        final_costs = np.full(self.count + 1, np.inf)
        final_costs[final_ids] = final_terms.total
        final_static_costs = np.full(self.count + 1, np.inf)
        final_static_costs[final_ids] = final_terms.static
        final_cp = np.zeros((self.count + 1, cfg.horizon_steps))
        final_cp[final_ids] = final_risk.collision_probability
        safe = (np.isfinite(final_costs)
                & (np.max(final_cp, axis=1) <= cfg.dynamic_risk.hard_threshold)
                & ~final_static)
        selection = final_costs.copy()
        selection[~safe] = np.inf
        if self.previous is not None and self.previous < self.count:
            # Penalize only transitions between moving guides. Stop is a
            # fallback, not a candidate that competes with safe motion.
            penalties = np.full(
                self.count + 1,
                cfg.guide_switch_penalty,
                dtype=float,
            )
            penalties[self.previous] = 0.0
            penalties[self.count] = 0.0
            selection += penalties
        status = 'ok'
        moving_safe = safe[:self.count]
        if not np.any(moving_safe):
            selected = self.count
            if not safe[self.count]:
                # Hold is not claimed collision-free.
                status = 'no_safe_candidate_hold'
        else:
            # A safe moving guide always takes precedence over Stop, regardless
            # of their relative costs. Compare costs only among moving guides.
            selection[self.count] = np.inf
            selected = int(np.argmin(selection[:self.count]))
            if (self.previous is not None
                    and self.previous < self.count
                    and moving_safe[self.previous]
                    and selected != self.previous
                    and selection[selected] + cfg.guide_hysteresis
                    >= final_costs[self.previous]):
                selected = self.previous
        for g in range(self.count):
            if valid[g]:
                self.nominals[g, :-1] = representatives[g, 1:]
                self.nominals[g, -1] = representatives[g, -1]
                self.initialized[g] = True
            else:
                self.initialized[g] = False
            if valid[g] and not safe[g]:
                reasons[g] = (
                    'representative_static_collision'
                    if final_static[g]
                    else 'representative_dynamic_risk'
                )
        # Retain Stop for diagnostics. It does not delay restarting once any
        # moving guide becomes safe again.
        self.previous = selected
        # Equal representation in RViz, keeping group-local weights visible.
        groups = [g for g in range(self.count) if counts[g]]
        indices = []
        if groups:
            quota, rem = divmod(max(0, int(visual_count)), len(groups))
            for i, g in enumerate(groups):
                group = slices[g]
                n = min(counts[g], quota + (i < rem))
                indices.extend((group.start + np.argsort(-weights[group])[:n]).tolist())
        indices = np.asarray(indices, dtype=int)
        is_stop = selected == self.count
        finite = costs[np.isfinite(costs)]
        selected_weights = np.array([1.0]) if is_stop else weights[slices[selected]]
        return MppiResult(
            control=all_controls[selected, 0].copy(),
            control_sequence=all_controls[selected].copy(),
            reference_state=all_paths[selected, 0].copy(),
            reference_sequence=np.concatenate((all_paths[selected], all_controls[selected]), axis=1),
            trajectory=all_paths[selected], sampled_controls=controls,
            sampled_rollouts=trajectories[indices], rollout_costs=costs,
            weights=weights, cost_terms=terms, collision_probabilities=probabilities,
            cost=float(final_costs[selected]),
            max_collision_probability=float(np.max(final_cp[selected])),
            effective_sample_size=1.0 if is_stop else float(ess[selected]),
            temperature=0.0 if is_stop else float(temperatures[selected]),
            next_temperature=0.0 if is_stop else float(self.temperatures[selected]),
            weight_normalizer=1.0 if is_stop else float(normalizers[selected]),
            minimum_cost=float(np.min(finite)) if len(finite) else float('inf'),
            maximum_cost=float(np.max(finite)) if len(finite) else float('inf'),
            minimum_weight=float(np.min(selected_weights)),
            maximum_weight=float(np.max(selected_weights)),
            compute_time_ms=(time.perf_counter() - started) * 1000,
            strategy='guide_conditioned', selected_mode=self.names[selected],
            control_mode_ids=ids, mode_control_sequences=all_controls,
            mode_trajectories=all_paths, mode_final_costs=final_costs,
            mode_selection_costs=selection, mode_collision_probabilities=final_cp,
            mode_temperatures=np.r_[temperatures, 0.0],
            mode_next_temperatures=np.r_[self.temperatures, 0.0],
            mode_effective_sample_sizes=np.r_[ess, 1.0],
            mode_static_costs=final_static_costs,
            sampled_rollout_indices=indices,
            primary_risk_time_ms=primary_diagnostics.compute_time_ms,
            final_risk_time_ms=final_diagnostics.compute_time_ms,
            candidate_names=self.names, guide_anchors=anchor_paths,
            guide_active_mask=active, guide_rollout_counts=counts,
            guide_rejection_reasons=tuple(reasons),
            final_static_collisions=final_static, safety_status=status,
            selected_static_cost=float(final_static_costs[selected]),
            guide_mc_region_areas=guide_areas,
            guide_mc_sample_counts=guide_samples,
            final_mc_region_areas=final_diagnostics.region_areas.copy(),
            final_mc_sample_counts=final_diagnostics.sample_counts.copy(),
        )
