#!/usr/bin/env python3
"""Small kinematic closed-loop pilot using the actual shared-cost controllers.

Not a physics/MPC/command-gate simulation, predictor calibration, or ROS timing.
Same primary K for all methods; final re-evaluation counts differ and are reported.
"""

import argparse
from dataclasses import asdict, replace
import json
from pathlib import Path
import time

import numpy as np

from benchmark_guide_conditioned import config_from_yaml
from dra_mppi.dynamic_risk import PredictionSet
from dra_mppi.grid_costmap import DistanceField, GridMetadata
from dra_mppi.mppi_controller import MppiController


def scene(name):
    grid = np.zeros((200, 200), dtype=np.int16)
    grid[:2, :] = 100
    path = np.array([[0., 0.], [2., 0.]])
    if name == 'detour':
        grid[90:110, 116:121] = 100
        path = np.array([[0., 0.], [.4, 1.], [1.5, 1.], [2., 0.]])
    field = DistanceField.from_occupancy(
        grid, GridMetadata(200, 200, .05, -5., -5., 0.))
    return path, field


def predictions(now, cfg):
    times = np.arange(1, cfg.horizon_steps+1)*cfg.dt
    means = np.zeros((5, 2, cfg.horizon_steps, 2))
    base = np.array([[.9, -1.], [1.6, 1.2], [2.5, -1.3], [3., 1.8], [3.5, -.8]])
    velocity = np.array([[0., .3], [0., -.15], [-.08, .1], [-.1, -.1], [0., .05]])
    means[:, 0] = base[:, None]+velocity[:, None]*(now+times)[None, :, None]
    means[:, 1] = means[:, 0]
    means[:, 1, :, 0] += .15*times
    covariance = np.broadcast_to(np.eye(2)*.02, (5, 2, cfg.horizon_steps, 2, 2)).copy()
    return PredictionSet(means, covariance, times, np.tile([.7, .3], (5, 1)))


def run(name, method, seed, base, steps, stream):
    cfg = replace(base, num_rollouts=base.guide_num_rollouts, seed=seed,
                  strategy='standard' if method == 'standard' else 'guide_conditioned',
                  guide_angles_deg=(0.,) if method == 'single_anchor' else base.guide_angles_deg)
    controller = MppiController(cfg)
    path, field = scene(name)
    state, current = np.zeros(3), np.zeros(3)
    success = collision = False
    minimum_clearance = float('inf')
    stop_steps = unsafe_steps = exceptions = 0
    input_change, durations = [], []
    for step in range(steps):
        pred = predictions(step*cfg.dt, cfg) if name == 'crossing5' else None
        tick = time.perf_counter()
        try:
            result = controller.compute(state, path, current, pred,
                                        visualization_rollouts=0, distance_field=field)
            control = result.control
            next_state = result.trajectory[0]
            risk = result.max_collision_probability
            unsafe_steps += int(risk > cfg.dynamic_risk.hard_threshold)
        except RuntimeError:
            control = controller._make_stopping_control(current)[0]
            from dra_mppi.mecanum_model import rollout
            next_state = rollout(state, control[None], cfg.dt)[0]
            risk = None
            exceptions += 1
        elapsed = (time.perf_counter()-tick)*1000.
        durations.append(elapsed)
        clearance = field.trajectory_clearances(
            next_state[None, None, :2], state[:2])[0, 0]-cfg.static_cost_robot_radius
        hit = field.trajectory_collisions(
            next_state[None, None, :2], state[:2], cfg.static_cost_robot_radius)[0]
        if pred is not None:
            # Deterministic CV truth; sample substeps for collisions between cycles.
            fractions = np.linspace(0., 1., 21)
            robot = state[:2]+fractions[:, None]*(next_state[:2]-state[:2])
            before = predictions((step-1)*cfg.dt, cfg).means[:, 0, 0]
            after = pred.means[:, 0, 0]
            obstacles = before[:, None]+fractions[None, :, None]*(after-before)[:, None]
            dynamic_clearance = np.linalg.norm(robot[None]-obstacles, axis=-1)-(
                cfg.dynamic_risk.robot_radius+cfg.dynamic_risk.obstacle_radius)
            clearance = min(clearance, float(dynamic_clearance.min()))
            hit |= bool(np.any(dynamic_clearance <= 0.))
        minimum_clearance = min(minimum_clearance, float(clearance))
        stop_steps += int(np.linalg.norm(control[:2]) < .03)
        input_change.append(float(np.sum(((control-current)/cfg.dt)**2)))
        stream.write(json.dumps({
            'environment': name, 'method': method, 'seed': seed, 'step': step,
            'state': state.tolist(), 'control': control.tolist(), 'risk': risk,
            'clearance_lower_bound': float(clearance), 'optimizer_ms': elapsed,
            'collision': bool(hit)})+'\n')
        state, current = next_state, control
        collision |= bool(hit)
        success = np.linalg.norm(state[:2]-path[-1]) < .15
        if success or collision:
            break
    controller.close()
    return {
        'environment': name, 'method': method, 'seed': seed, 'success': bool(success and not collision),
        'collision': collision, 'elapsed_sim_s': (step+1)*cfg.dt,
        'failure_inclusive_s': (step+1)*cfg.dt if success and not collision else steps*cfg.dt,
        'minimum_clearance_lower_bound': minimum_clearance,
        'stop_time_s': stop_steps*cfg.dt, 'risk_exceed_steps': unsafe_steps,
        'exceptions': exceptions, 'mean_input_rate_squared': float(np.mean(input_change)),
        'offline_optimizer_p99_ms': float(np.percentile(durations, 99)),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seeds', type=int, default=3)
    parser.add_argument('--steps', type=int, default=100)
    parser.add_argument('--rollouts', type=int, default=60)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    base = replace(config_from_yaml(), guide_num_rollouts=args.rollouts,
                   static_cost_enabled=True)
    environments = ('open', 'detour', 'crossing5')
    methods = ('standard', 'single_anchor', 'guide')
    results = []
    with (args.output/'closed_loop_raw.jsonl').open('w') as stream:
        for name in environments:
            for seed in range(args.seeds):
                for method in methods:
                    results.append(run(name, method, seed, base, args.steps, stream))
    paired = []
    for name in environments:
        means = {method: np.mean([r['failure_inclusive_s'] for r in results
                                 if r['environment'] == name and r['method'] == method])
                 for method in methods}
        paired.append(means['guide']-means['standard'])
    bootstrap = np.random.default_rng(73).choice(
        paired, (10000, len(environments)), replace=True).mean(axis=1)
    report = {
        'scope': 'kinematic synthetic pilot, three environments; no tuning',
        'config': asdict(base), 'primary_K': args.rollouts,
        'final_candidates': {'standard': 2, 'single_anchor': 2, 'guide': 6},
        'results': results, 'independent_environment_count': len(environments),
        'paired_environment_mean_time_difference_s': float(np.mean(paired)),
        'exploratory_environment_bootstrap_95_ci_s': np.percentile(bootstrap, [2.5, 97.5]).tolist(),
        'limitations': 'Three hand-built scenes; seeds are repeats within environments. '
        'No time-budget matching, MPC dynamics, measured prediction error, perception load, '
        'or ROS deadline/physical collision relationship. Collision checks are discretized. '
        'Zero observed collisions is not a safety guarantee.',
    }
    (args.output/'closed_loop_summary.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({method: {
        'successes': sum(r['success'] for r in results if r['method'] == method),
        'collisions': sum(r['collision'] for r in results if r['method'] == method),
        'trials': sum(r['method'] == method for r in results)} for method in methods}, indent=2))


if __name__ == '__main__':
    main()
