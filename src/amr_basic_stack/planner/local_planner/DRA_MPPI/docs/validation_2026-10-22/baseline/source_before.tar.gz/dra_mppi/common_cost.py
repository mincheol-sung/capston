"""Shared, normalized guide/baseline objective (application design, not SMPPI)."""

import numpy as np

from .geometry import wrap_angle


def project_path(positions, path, lookahead, window, initial_progress=None):
    """Project a batch of time sequences with a bidirectional arc-length window.

    Duplicate vertices are removed. The first unseeded point uses the nearest
    segment (earliest segment breaks ties); subsequent points search within
    max(window, twice the travelled distance) of the preceding projection.
    Reverse motion can decrease progress. A singleton path holds zero heading.
    """
    points = np.asarray(path, dtype=float)[:, :2]
    keep = np.r_[True, np.linalg.norm(np.diff(points, axis=0), axis=1) > 1e-9]
    points = points[keep]
    xy = np.asarray(positions, dtype=float)
    k, n = xy.shape[:2]
    if len(points) == 1:
        closest = np.broadcast_to(points[0], xy.shape).copy()
        return closest, np.zeros((k, n)), np.zeros((k, n)), np.zeros((k, n)), 0.
    segments = np.diff(points, axis=0)
    lengths = np.linalg.norm(segments, axis=1)
    tangent = segments / lengths[:, None]
    arc = np.r_[0., np.cumsum(lengths)]

    def at(s):
        idx = np.clip(np.searchsorted(arc, s, side='right') - 1, 0, len(lengths)-1)
        return points[idx] + (s - arc[idx])[..., None] * tangent[idx], idx

    closest = np.empty_like(xy)
    progress = np.empty((k, n))
    headings = np.empty((k, n))
    tangents = np.empty((k, n))
    previous = None if initial_progress is None else np.broadcast_to(initial_progress, (k,))
    rows = np.arange(k)
    for t in range(n):
        lower = np.broadcast_to(arc[:-1], (k, len(lengths))).copy()
        upper = np.broadcast_to(arc[1:], lower.shape).copy()
        if previous is not None:
            travel = 0. if t == 0 else 2*np.linalg.norm(xy[:, t]-xy[:, t-1], axis=1)
            reach = np.maximum(window, travel)
            lower = np.maximum(lower, (previous-reach)[:, None])
            upper = np.minimum(upper, (previous+reach)[:, None])
        relative = xy[:, t, None] - points[:-1]
        s = arc[:-1] + np.sum(relative*tangent, axis=-1)
        s = np.minimum(np.maximum(s, lower), upper)
        projections = points[:-1] + (s-arc[:-1])[..., None]*tangent
        squared = np.sum((xy[:, t, None]-projections)**2, axis=-1)
        squared[lower > upper] = np.inf
        idx = np.argmin(squared, axis=1)
        previous = s[rows, idx]
        progress[:, t] = previous
        closest[:, t] = projections[rows, idx]
        ahead, _ = at(np.minimum(previous+lookahead, arc[-1]))
        direction = ahead-closest[:, t]
        zero = np.linalg.norm(direction, axis=-1) < 1e-9
        direction[zero] = tangent[idx[zero]]
        headings[:, t] = np.arctan2(direction[:, 1], direction[:, 0])
        tangents[:, t] = np.arctan2(tangent[idx, 1], tangent[idx, 0])
    return closest, progress, headings, tangents, float(arc[-1])


def common_costs(cfg, state, path, controls, trajectories, current, progress=None):
    """Return path, heading, path-speed and rotation/input-rate costs.

    States are x_1..x_N from u_0..u_(N-1). State costs use x_1..x_N;
    world velocity uses x_0..x_(N-1), matching the Euler rollout.
    """
    initial = np.broadcast_to(state, (len(controls), 1, 3))
    states = np.concatenate((initial, trajectories), axis=1)
    closest, s, heading, tangent, length = project_path(
        states[..., :2], path, cfg.heading_lookahead, cfg.projection_window, progress)
    error = np.linalg.norm(trajectories[..., :2]-closest[:, 1:], axis=-1)
    z = error/cfg.path_distance_scale
    rho = (np.where(z <= 1., .5*z*z, z-.5)
           if cfg.path_loss == 'huber' else .5*z*z)
    tracking = cfg.tracking_path_weight*np.mean(rho, axis=1)
    tracking -= cfg.progress_weight*(s[:, -1]-s[:, 0])/cfg.progress_scale
    # Only the actual path endpoint, and only when already in its goal region.
    near_goal = (length-s[:, 0] <= cfg.goal_activation_distance) & (
        np.linalg.norm(state[:2]-path[-1]) <= cfg.goal_activation_distance)
    tracking += near_goal*cfg.tracking_goal_weight*np.sum(
        (trajectories[:, -1, :2]-path[-1])**2, axis=-1)
    heading_cost = cfg.heading_weight*np.mean(
        wrap_angle(trajectories[..., 2]-heading[:, 1:])**2, axis=1)
    yaw = states[:, :-1, 2]
    vx, vy = controls[..., 0], controls[..., 1]
    world_x = np.cos(yaw)*vx-np.sin(yaw)*vy
    world_y = np.sin(yaw)*vx+np.cos(yaw)*vy
    tau = tangent[:, :-1]
    parallel = np.cos(tau)*world_x+np.sin(tau)*world_y
    perpendicular = -np.sin(tau)*world_x+np.cos(tau)*world_y
    remaining = np.maximum(length-s[:, :-1], np.linalg.norm(
        states[:, :-1, :2]-path[-1], axis=-1))
    v_ref = np.minimum(cfg.desired_speed, np.sqrt(
        2*min(cfg.acceleration_limit[:2])*remaining))
    v_ref = np.minimum(v_ref, remaining/cfg.dt)
    speed = np.mean(cfg.speed_weight*((parallel-v_ref)/cfg.speed_scale)**2
                    + cfg.lateral_speed_weight*(perpendicular/cfg.speed_scale)**2, axis=1)
    previous = np.broadcast_to(current, (len(controls), 1, 3))
    rate = np.diff(np.concatenate((previous, controls), axis=1), axis=1)/cfg.dt
    rotation = cfg.rotation_weight*np.mean((controls[..., 2]/cfg.omega_scale)**2, axis=1)
    rotation += np.mean(np.sum(
        np.asarray(cfg.input_rate_weight)*(rate/np.asarray(cfg.input_rate_scale))**2,
        axis=-1), axis=1)
    return tracking, heading_cost, speed, rotation
